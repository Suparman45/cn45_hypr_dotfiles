#!/usr/bin/env bash
# /* https://github.com/Suparman45 */
# CN45-Look SDDM Sync Module

# --- SDDM Wallpaper Sync ---
SDDM_THEME_DIR="/usr/share/sddm/themes"
DEFAULT_SDDM_THEME="Sweet6/assets"

sync_sddm_wallpaper() {
    local img="$1"
    if [ ! -f "$img" ]; then
        ${PREFIX}-log -e "Invalid file: $img"
        return 1
    fi
    local target="$SDDM_THEME_DIR/$DEFAULT_SDDM_THEME/default"
    if [ -w "$(dirname "$target")" ]; then
        app2unit -s a $APP_TERM -e sudo cp "$img" "$target"
    elif command -v sudo >/dev/null 2>&1; then
        app2unit -s a $APP_TERM -e sudo cp "$img" "$target"
    else
        ${PREFIX}-log -w "Cannot copy to $target (no write access or sudo)"
        return 1
    fi
    ${PREFIX}-log -s "Wallpaper synced to SDDM ($DEFAULT_SDDM_THEME)"
}


