#!/usr/bin/env bash
# /* https://github.com/Suparman45 */
# Wallpaper Module

WALLPAPER_DIR="${WALL_DIR:-$HOME/Pictures/wallpapers}"
MPVPAPER_DIR="${MPV_DIR:-$HOME/Videos/mpvpapers}"
STATE_DIR="${CN45_STATE_DIR:-$HOME/.local/state/cn45}"
CURRENT_LINK="$STATE_DIR/.current_wallpaper"

ensure_dirs() { mkdir -p "$STATE_DIR" "$WALLPAPER_DIR" "$MPVPAPER_DIR"; }

get_current_wallpaper() {
    [ -L "$CURRENT_LINK" ] && readlink -f "$CURRENT_LINK" || echo ""
}

save_current_wallpaper() { ln -sf "$1" "$CURRENT_LINK"; }

detect_tool() {
    if [[ "$APP_WALL_SERVICE" == "awww" ]]; then echo "awww"
    elif [[ "$APP_WALL_SERVICE" == "mpvpaper" ]]; then echo "mpvpaper"
    else echo "none"; fi
}

# --- Dynamically list wallpapers supported by the active tool ---
list_wallpapers() {
    local tool
    tool=$(detect_tool)

    case "$tool" in
        awww)
            find "$WALLPAPER_DIR" -type f \( \
                -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' -o \
                -iname '*.webp' -o -iname '*.avif' -o -iname '*.bmp' -o -iname '*.gif' \
            \) -print0 | xargs -0 -I {} readlink -f {} | sort
            ;;
        mpvpaper)
            find "$MPVPAPER_DIR" -type f \( \
                -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' -o \
                -iname '*.webp' -o -iname '*.bmp' -o -iname '*.gif' -o \
                -iname '*.mp4' -o -iname '*.mkv' -o -iname '*.webm' \
            \) -print0 | xargs -0 -I {} readlink -f {} | sort
            ;;
        *)
            find "$WALLPAPER_DIR" -type f \( \
                -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' -o -iname '*.webp' \
            \) -print0 | xargs -0 -I {} readlink -f {} | sort
            ;;
    esac
}

set_wallpaper() {
    local img="$1"
    local tool monitor
    tool=$(detect_tool)
    monitor=$(detect_monitor)

    if [ -z "$img" ]; then
        notify-send -u critical "❌ Wallpaper change failed" "No image selected."
        return 1
    fi

    if [ ! -f "$img" ]; then
        notify-send -u critical "❌ Wallpaper change failed" "File not found: $img"
        return 1
    fi

    if [ "$tool" = "awww" ]; then
        pgrep -x awww-daemon >/dev/null || { awww-daemon --format xrgb & sleep 1; }
        ${PREFIX}-run -s b awww img "$img" \
            --transition-type fade \
            --transition-fps 60 \
            --transition-duration 1 \
            --transition-pos "$(hyprctl cursorpos 2>/dev/null || echo '0,0')" \
            >/dev/null 2>&1
    elif [ "$tool" = "mpvpaper" ]; then
        pkill mpvpaper >/dev/null 2>&1
        ${PREFIX}-run -s b mpvpaper "$monitor" "$img" --no-audio --loop >/dev/null 2>&1 &
    else
        notify-send -u critical "⚠️ Wallpaper tool not found" "Please install awww or mpvpaper."
        return 1
    fi

    save_current_wallpaper "$img"
    notify-send -i "$img" "Wallpaper Updated ✅" "Now using: $(basename "$img")"
}

random_wallpaper() {
    ${PREFIX}-log -s "Wallpaper random applied"
    local img
    img=$(list_wallpapers | shuf -n 1)
    set_wallpaper "$img"

}

next_wallpaper() {
    ${PREFIX}-log -s "Wallpaper next applied"
    local list current next_index
    current=$(get_current_wallpaper)
    mapfile -t list < <(list_wallpapers)
    for i in "${!list[@]}"; do
        if [ "${list[$i]}" = "$current" ]; then
            next_index=$(( (i + 1) % ${#list[@]} ))
            set_wallpaper "${list[$next_index]}"
            return
        fi
    done
    set_wallpaper "${list[0]}"
}

prev_wallpaper() {
    ${PREFIX}-log -s "Wallpaper previous applied"
    local list current prev_index
    current=$(get_current_wallpaper)
    mapfile -t list < <(list_wallpapers)
    for i in "${!list[@]}"; do
        if [ "${list[$i]}" = "$current" ]; then
            prev_index=$(( (i - 1 + ${#list[@]}) % ${#list[@]} ))
            set_wallpaper "${list[$prev_index]}"
            return
        fi
    done
    set_wallpaper "${list[-1]}"
}

