#!/usr/bin/env bash
# /* https://github.com/Suparman45 */

# Folder to save screenshots
SAVE_DIR="${SSHOT_DIR:-$HOME/Pictures/Screenshots}"
mkdir -p "$SAVE_DIR"

# Timestamp for unique filename
TIME=$(date +"%Y-%m-%d_%H-%M-%S")
FULL="$SAVE_DIR/screenshot_full_$TIME.png"
AREA="$SAVE_DIR/screenshot_area_$TIME.png"
SWAPPY="$SAVE_DIR/screenshot_swappy_$TIME.png"

# 1-line notify-send function
notify() {
    local msg="$1"
    local icon="$2"
    notify-send -u low -i "$icon" "$msg"
}

# Full screenshot using grim
screenshot_full() {
    app2unit -s a grim "$FULL"
    notify "📸 Image has saved"
}

# Area screenshot using slurp
screenshot_area() {
    app2unit -s a  grim -g "$(slurp)" "$AREA"
    notify "🔲 Image has saved"
}

# Area screenshot + Swappy edit
screenshot_swappy() {
    app2unit -s a  grim -g "$(slurp)" /tmp/swappy_tmp.png
    app2unit -s a  swappy -f /tmp/swappy_tmp.png -o "$SWAPPY"
    notify "✏️ Image has saved"
}
