#!/usr/bin/env bash
# /* https://github.com/Suparman45 */
# CN45-Look CLI Dispatcher

# --- Argument Parser (File Manager Friendly) ---
flag="${1:-}"
target="${2:-}"
ensure_dirs

# Wallpaper
if [ "$flag" = "-w" ]; then
    shift 2
    case "$target" in
        random) random_wallpaper ;;
        next) next_wallpaper ;;
        prev) prev_wallpaper ;;
        set) set_wallpaper "$@" ;;
        sddm) sync_sddm_wallpaper "$@" ;;
        gallery) gui --wallpaper ;;
        *) ${PREFIX}-log -e "🗿 Error: wrong argument" ;;
    esac

# Screenshot
elif [ "$flag" = "-s" ]; then
    shift 2
    case "$target" in
    full) screenshot_full ;;
    area) screenshot_area ;;
    edit) screenshot_swappy ;;
    *) ${PREFIX}-log -e "🗿 Error: wrong argument" ;;
   esac

# Gui menu
elif [ "$flag" = "--menu" ]; then
    shift 2
      gui --menu

else  ${PREFIX}-log -e "🗿 Error: wrong argument"
fi
