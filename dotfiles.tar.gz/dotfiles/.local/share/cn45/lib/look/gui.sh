#!/usr/bin/env bash
# /* https://github.com/Suparman45 */
# GUI Module

gui() {
    case "$1" in

        --wallpaper)
            if pgrep nemo > /dev/null; then
                ${PREFIX}-kill -a nemo
            else
                case "$APP_WALL_SERVICE" in
                    swww) ${PREFIX}-run -s a nemo "$WALLPAPER_DIR" ;;
                    mpvpaper) ${PREFIX}-run -s a nemo "$MPVPAPER_DIR" ;;
                    *) notify-send "Wallpaper" "Service not found" ;;
                esac
            fi
            ;;

        --monitor)
            if pgrep nwg-displays > /dev/null; then
                ${PREFIX}-kill -a nwg-displays
            else
                ${PREFIX}-run -s a nwg-displays
            fi
            ;;

        --gtk)
            if pgrep nwg-look > /dev/null; then
                ${PREFIX}-kill -a nwg-look
            else
                ${PREFIX}-run -s a nwg-look
            fi
            ;;

        --qt)
            if pgrep kvantummanager > /dev/null; then
                ${PREFIX}-kill -a kvantummanager
            else
                ${PREFIX}-run -s a kvantummanager
            fi
            ;;

        --hyconf)
            if pgrep nemo > /dev/null; then
                ${PREFIX}-kill -a nemo
            else
                ${PREFIX}-run -s a nemo "$CN45_DATA_DIR/hypr/configs"
            fi
            ;;

        --wybmod)
            if pgrep nemo > /dev/null; then
                ${PREFIX}-kill -a nemo
            else
                ${PREFIX}-run -s a nemo "$CN45_DATA_DIR/waybar/modules"
            fi
            ;;

        --cn45conf)
            if pgrep micro > /dev/null; then
                ${PREFIX}-kill -a micro
            else
                ${PREFIX}-run -s a foot -e micro "$CN45_CONFIG_DIR/configs.toml"
            fi
            ;;

        --log)
            if pgrep yad > /dev/null; then
                ${PREFIX}-kill -a yad
            else
                (
                    ${PREFIX}-run -s a yad --title="System Log" \
                        --window-icon=preferences-system \
                        --width=200 \
                        --height=100 \
                        --center \
                        --list \
                        --no-headers \
                        --column="Menu" \
                        --column="Action" \
                        --hide-column=2 \
                        --print-column=2 \
                        --separator="|" \
                        --on-top \
                        --no-buttons \
                        "DEBUG"    "${PREFIX}-run -e $CN45_STATE_DIR/log/cn45.DEBUG.log" \
                        "ERROR"    "${PREFIX}-run -e $CN45_STATE_DIR/log/cn45.ERROR.log" \
                        "INFO"     "${PREFIX}-run -e $CN45_STATE_DIR/log/cn45.INFO.log" \
                        "SUCCESS"  "${PREFIX}-run -e $CN45_STATE_DIR/log/cn45.SUCCESS.log" \
                        "WARN"     "${PREFIX}-run -e $CN45_STATE_DIR/log/cn45.WARN.log" \
                    | while IFS="|" read -r action; do
                        [[ -n "$action" ]] && $action
                    done
                )
            fi
            ;;

        --menu)
            if pgrep yad > /dev/null; then
                ${PREFIX}-kill -a yad
            else
                (
                    ${PREFIX}-run -s a yad --title="System Control Center" \
                        --window-icon=preferences-system \
                        --width=500 \
                        --height=400 \
                        --center \
                        --list \
                        --no-headers \
                        --column="Menu" \
                        --column="Action" \
                        --hide-column=2 \
                        --print-column=2 \
                        --separator="|" \
                        --on-top \
                        --no-buttons \
                        "🖼  Wallpaper"        "gui --wallpaper" \
                        "🖥  Monitor"          "gui --monitor" \
                        "🎨  GTK Theme"        "gui --gtk" \
                        "🧩  Qt Theme"         "gui --qt" \
                        "⚙️  Hyprland Config"  "gui --hyconf" \
                        "📊  Waybar Modules"    "gui --wybmod" \
                        "🛠  CN45 Config"      "gui --cn45conf" \
                        "🗿 Log"               "gui --log" \
                    | while IFS="|" read -r action; do
                        [[ -n "$action" ]] && $action
                    done
                )
            fi
            ;;

    esac
}
