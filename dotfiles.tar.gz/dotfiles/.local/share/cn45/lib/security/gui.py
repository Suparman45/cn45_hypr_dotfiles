#!/usr/bin/env python3

import os
import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Vte", "3.91")

from gi.repository import Gtk, Adw, Vte, GLib

APP_ID = "com.cn45.security"
SECURITY_BIN = os.path.expanduser("~/.local/bin/cn45-secure")

Adw.init()


class SecurityWindow(Adw.ApplicationWindow):

    def __init__(self, app):
        super().__init__(application=app)

        self.set_title("CN45 Security")
        self.set_default_size(960, 640)

        Adw.StyleManager.get_default().set_color_scheme(
            Adw.ColorScheme.FORCE_DARK
        )

        self._build_ui()

    # ==============================
    # UI
    # ==============================

    def _build_ui(self):

        self.toast_overlay = Adw.ToastOverlay()
        self.set_content(self.toast_overlay)

        toolbar = Adw.ToolbarView()
        self.toast_overlay.set_child(toolbar)

        header = Adw.HeaderBar()
        header.set_title_widget(Gtk.Label(label="CN45 Security"))
        toolbar.add_top_bar(header)

        content = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12
        )
        content.set_margin_top(12)
        content.set_margin_bottom(12)
        content.set_margin_start(12)
        content.set_margin_end(12)

        toolbar.set_content(content)

        # ==============================
        # GRID BUTTONS
        # ==============================

        grid = Gtk.FlowBox()
        grid.set_max_children_per_line(3)
        grid.set_selection_mode(Gtk.SelectionMode.NONE)
        grid.set_row_spacing(8)
        grid.set_column_spacing(8)
        content.append(grid)

        self.buttons = []

        actions = [
            ("🔒 Secure", "--secure"),
            ("🛡 Scan", "--scan"),
            ("🟧 Menu", "--menu"),
        ]

        for label, arg in actions:
            btn = Gtk.Button(label=label)
            btn.set_hexpand(True)
            btn.connect("clicked", self.on_action_clicked, arg)
            grid.append(btn)
            self.buttons.append(btn)

        # ==============================
        # STATUS AREA
        # ==============================

        status_box = Gtk.Box(spacing=8)
        content.append(status_box)

        self.spinner = Gtk.Spinner()
        status_box.append(self.spinner)

        self.status_label = Gtk.Label(label="Ready")
        self.status_label.set_xalign(0)
        status_box.append(self.status_label)

        # ==============================
        # TERMINAL
        # ==============================

        self.terminal = Vte.Terminal()
        self.terminal.set_vexpand(True)
        self.terminal.connect("child-exited", self.on_child_exited)
        content.append(self.terminal)

    # ==============================
    # RUN PROCESS
    # ==============================

    def on_action_clicked(self, button, argument):

        if not os.path.exists(SECURITY_BIN):
            self._toast("Binary not found!")
            return

        self._disable_buttons()
        self.spinner.start()
        self.status_label.set_label("Running...")

        self.terminal.reset(True, True)

        self.terminal.spawn_async(
            Vte.PtyFlags.DEFAULT,
            os.environ["HOME"],
            [SECURITY_BIN, argument],
            [],
            GLib.SpawnFlags.DEFAULT,
            None,
            None,
            -1,
            None,
            self.on_spawn_ready
        )

    def on_spawn_ready(self, terminal, task):
        try:
            terminal.spawn_async_finish(task)
        except Exception as e:
            self._toast(str(e))
            self.spinner.stop()
            self._enable_buttons()

    # ==============================
    # PROCESS EXIT
    # ==============================

    def on_child_exited(self, terminal, status):

        self.spinner.stop()
        self._enable_buttons()

        if status == 0:
            self.status_label.set_label("Finished")
            self._toast("Process completed")
        else:
            self.status_label.set_label(f"Exited ({status})")

    # ==============================
    # UTILITIES


    # ==============================

    def _disable_buttons(self):
        for b in self.buttons:
            b.set_sensitive(False)

    def _enable_buttons(self):
        for b in self.buttons:
            b.set_sensitive(True)

    def _toast(self, msg):
        self.toast_overlay.add_toast(Adw.Toast(title=msg))


class SecurityApp(Adw.Application):

    def __init__(self):
        super().__init__(application_id=APP_ID)

    def do_activate(self):
        win = SecurityWindow(self)
        win.present()


if __name__ == "__main__":
    app = SecurityApp()
    app.run()
