#!/usr/bin/env bash

ROOT="$HOME/.local/share/cn45/lib/security/aur-malware-check"

export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"

exec python3 -m aur_check "$@"
