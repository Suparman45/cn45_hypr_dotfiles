#!/usr/bin/env bash
# CN45 Pacman Maintenance & Security Toolkit
# Author: https://github.com/Suparman45
# Arch / CachyOS Compatible

# ───────────────────────────────────────────────
# Install Tools
install_tools() {
    tools=(
        # Firewall & security
        ufw
        apparmor
        audit
        fail2ban
        lynis
        rkhunter
        chkrootkit
        clamav
        aide
        bubblewrap

        # Python
        python3
        python-pip

        # GTK / Terminal
        gtk4
        vte
    )

    info "Checking all required CN45 tools..."

    for pkg in "${tools[@]}"; do
        if command -v "$pkg" >/dev/null 2>&1; then
            success "$pkg already installed."
            continue
        fi

        warn "$pkg not found. Installing..."

        # Pastikan Alacritty ada dulu
        if ! command -v alacritty >/dev/null 2>&1; then
            echo -e "\e[33m[WARN]\e[0m Alacritty not found. Installing first..."
            if command -v paru &>/dev/null; then
                sudo paru -S --noconfirm alacritty
            elif command -v yay &>/dev/null; then
                sudo yay -S --noconfirm alacritty
            else
                sudo pacman -S --noconfirm alacritty
            fi
        fi

        # Buka Alacritty hanya untuk instalasi paket yang hilang
        alacritty -e bash -c "
PKG='$pkg'
echo -e '\e[36m[INFO]\e[0m Installing \$PKG...'

INSTALL_CMD='sudo pacman -S --noconfirm \$PKG'
if command -v paru >/dev/null 2>&1; then
    INSTALL_CMD='sudo paru -S --noconfirm \$PKG'
elif command -v yay >/dev/null 2>&1; then
    INSTALL_CMD='sudo yay -S --noconfirm \$PKG'
fi

\$INSTALL_CMD

echo -e '\e[32m[OK]\e[0m \$PKG installed.'
exec bash
"
    done

    info "All CN45 required tools are ready."
}

# ───────────────────────────────────────────────
# Fix Pacman DB Lock
fix_pacman_lock() {
  pkexec bash -c '
    lock="/var/lib/pacman/db.lck"
    if [[ -f "$lock" ]]; then
        echo -e "\e[33m[WARN]\e[0m Pacman DB lock detected."
        read -rp "? Remove lock and kill pacman/pamac processes? (y/N): " answer
        if [[ "$answer" =~ ^[Yy]$ ]]; then
            sudo pkill -9 pacman 2>/dev/null || true
            sudo pkill -9 pamac 2>/dev/null || true
            sudo rm -f "$lock"
            echo -e "\e[32m[OK]\e[0m Pacman DB lock removed."
        fi
    else
        echo -e "\e[32m[OK]\e[0m No DB lock found."
    fi
  '
}

# ───────────────────────────────────────────────
# Optimize System
run_optimize() {
  pkexec bash -c '
    echo -e "\e[32m=== OPTIMIZE MODE ===\e[0m"
    $0 fix_pacman_lock
    echo -e "\e[36m[INFO]\e[0m Syncing database..."
    sudo pacman -Sy --noconfirm &>/dev/null || true
    echo -e "\e[36m[INFO]\e[0m Cleaning old cache (>30 days)..."
    sudo find /var/cache/pacman/pkg -type f -mtime +30 -delete || true
    echo -e "\e[36m[INFO]\e[0m Removing orphan packages..."
    orphans="$(pacman -Qtdq 2>/dev/null || true)"
    if [[ -n "$orphans" ]]; then
        sudo pacman -Rns --noconfirm $orphans
    else
        echo -e "\e[32m[OK]\e[0m No orphan packages found."
    fi
    echo -e "\e[36m[INFO]\e[0m Cleaning journal..."
    sudo journalctl --vacuum-size=200M --vacuum-time=7d &>/dev/null || true
    echo -e "\e[36m[INFO]\e[0m Verifying packages..."
    sudo pacman -Qk &>/dev/null || true
    echo -e "\e[32m[OK]\e[0m Optimization completed successfully."
  '
}

# ───────────────────────────────────────────────
# Full Hardener + Firewall
secure_mode() {
    pkexec bash -c '
echo -e "\e[32m=== FULL HARDENER MODE ===\e[0m"

# Select mode
echo "1) Gaming Secure Mode"
echo "2) Ultra Secure Mode"
read -rp "Select mode: " mode

echo -e "\e[36m[INFO]\e[0m Enabling security services..."
for service in fail2ban apparmor auditd; do
    if systemctl is-active --quiet $service; then
        echo -e "\e[36m[INFO]\e[0m $service is already active, skipping..."
    else
        echo -e "\e[36m[INFO]\e[0m Starting $service..."
        sudo systemctl enable --now $service || true
    fi
done

echo -e "\e[36m[INFO]\e[0m Applying kernel hardening..."
sudo bash -c "cat > /etc/sysctl.d/99-cn45.conf <<EOF
kernel.kptr_restrict=2
kernel.dmesg_restrict=1
kernel.randomize_va_space=2
kernel.sysrq=0
kernel.yama.ptrace_scope=2
net.ipv4.tcp_syncookies=1
net.ipv4.conf.all.accept_redirects=0
net.ipv4.conf.all.accept_source_route=0
net.ipv4.conf.all.rp_filter=1
fs.protected_hardlinks=1
fs.protected_symlinks=1
EOF"

sudo sysctl --system &>/dev/null || true

# SSH hardening
if [[ -f /etc/ssh/sshd_config ]]; then
    echo -e "\e[36m[INFO]\e[0m Hardening SSH..."
    sudo sed -i "s/^#*PermitRootLogin.*/PermitRootLogin no/" /etc/ssh/sshd_config
    sudo sed -i "s/^#*MaxAuthTries.*/MaxAuthTries 3/" /etc/ssh/sshd_config
    if systemctl is-active --quiet sshd; then
        echo -e "\e[36m[INFO]\e[0m Restarting sshd..."
        sudo systemctl restart sshd || true
    else
        echo -e "\e[36m[INFO]\e[0m Starting sshd..."
        sudo systemctl start sshd || true
    fi
fi

# Firewall configuration
echo -e "\e[36m[INFO]\e[0m Configuring firewall..."
if sudo ufw status | grep -q "Status: active"; then
    echo -e "\e[36m[INFO]\e[0m UFW already active, resetting..."
    sudo ufw --force reset
fi

sudo ufw default deny incoming
sudo ufw default allow outgoing

case "$mode" in
    1)
        # Gaming mode: allow common game ports
        sudo ufw allow 27015:27030/udp
        sudo ufw allow 27036/udp
        ;;
    2)
        # Ultra secure mode: block ICMP
        sudo ufw deny in proto icmp
        ;;
    *)
        echo -e "\e[33m[WARN]\e[0m Invalid mode."
        exit 1
        ;;
esac

sudo ufw --force enable

# Apply immutable audit rules safely
echo -e "\e[36m[INFO]\e[0m Applying immutable audit rules..."
sudo bash -c "cat > /etc/audit/rules.d/cn45.rules <<EOF
-w /etc/passwd -p wa -k identity
-w /etc/shadow -p wa -k identity
-w /etc/sudoers -p wa -k privilege
-a always,exit -F arch=b64 -S execve -F euid=0 -k root_exec
-e 2
EOF"

# Safe auditd handling
if systemctl list-unit-files | grep -q '^auditd.service'; then
    if systemctl is-active --quiet auditd; then
        echo -e "\e[36m[INFO]\e[0m Reloading audit rules..."
        sudo augenrules --load || true
        sudo systemctl start auditd || true
    else
        echo -e "\e[36m[INFO]\e[0m Starting auditd..."
        sudo systemctl start auditd || true
    fi
else
    echo -e "\e[33m[WARN]\e[0m auditd service not found, skipping..."
fi

echo -e "\e[32m[OK]\e[0m Full hardening applied."

# Prompt for reboot
echo -e "\e[33m[WARN]\e[0m A reboot is recommended to apply all changes."
read -rp "Do you want to reboot now? [y/N]: " reboot_choice
if [[ "$reboot_choice" =~ ^[Yy]$ ]]; then
    echo -e "\e[36m[INFO]\e[0m Rebooting..."
    sudo reboot
else
    echo -e "\e[36m[INFO]\e[0m Reboot skipped. Please reboot manually later."
fi
'
}

# ───────────────────────────────────────────────
# Scan System
scan_mode() {
  pkexec bash -c '

  clear

  echo -e "\e[32m==============================="
  echo -e "        SECURITY SCAN MODE"
  echo -e "===============================\e[0m"
  echo ""
  echo "1) Quick Scan"
  echo "2) Full Security Scan"
  echo "3) AIDE Only"
  echo "4) Audit"
  echo ""
  read -p "Select option: " opt

  case $opt in

  1)
    echo -e "\e[36m[INFO]\e[0m Running Quick Scan..."

    sudo rkhunter --update || true
    sudo rkhunter --check --sk --rwo || true

    sudo freshclam || true
    sudo clamscan --infected /home || true

    echo -e "\e[32m[OK]\e[0m Quick Scan Completed."
    ;;

  2)
    echo -e "\e[36m[INFO]\e[0m Running FULL Security Scan..."

    # ===== AIDE FIX =====
    sudo pkill -9 aide 2>/dev/null
    sudo mkdir -p /var/lib/aide /var/log/aide
    sudo chown root:root /var/lib/aide /var/log/aide
    sudo chmod 700 /var/lib/aide /var/log/aide
    sudo rm -f /var/log/aide/aide.log

    #sudo sed -i "s|database_in=.*|database_in=file:/var/lib/aide/aide.db.gz|" /etc/aide.conf
    #sudo sed -i "s|database_out=.*|database_out=file:/var/lib/aide/aide.db.new.gz|" /etc/aide.conf
    #sudo sed -i "s|report_url=.*|report_url=file:/var/log/aide/aide.log|" /etc/aide.conf

    if [ ! -f /var/lib/aide/aide.db.gz ]; then
        echo -e "\e[36m[INFO]\e[0m Initializing AIDE..."
        sudo aide --init
        sudo mv /var/lib/aide/aide.db.new.gz /var/lib/aide/aide.db.gz
    else
        echo -e "\e[36m[INFO]\e[0m Checking integrity with AIDE..."
        sudo aide --check
    fi

    # ===== ROOTKIT =====
    sudo rkhunter --update || true
    sudo rkhunter --propupd || true
    sudo rkhunter --check --sk --rwo || true

    # ===== CLAMAV =====
    sudo freshclam || true
    sudo clamscan -r --remove /home || true

    # ===== SYSTEM ERRORS =====
    echo -e "\e[36m[INFO]\e[0m Checking critical system logs..."
    journalctl -p 3 -xb | grep -i "failed" || true

    echo -e "\e[32m[OK]\e[0m FULL Scan Completed."
    ;;

  3)
    echo -e "\e[36m[INFO]\e[0m Running AIDE only..."

    sudo pkill -9 aide 2>/dev/null
    sudo rm -f /var/log/aide/aide.log

    if [ ! -f /var/lib/aide/aide.db.gz ]; then
        sudo aide --init
        sudo mv /var/lib/aide/aide.db.new.gz /var/lib/aide/aide.db.gz
    else
        sudo aide --check
    fi

    echo -e "\e[32m[OK]\e[0m AIDE scan completed."
    ;;

  4)
    echo -e "\e[36m[INFO]\e[0m Running Audit..."

    lynis audit system

    echo -e "\e[32m[OK]\e[0m Audit scan completed."
    ;;

  *)
    echo "Invalid option."
    ;;
  esac

  '
}

# ───────────────────────────────────────────────
# Helper
pause() { read -rp "Press ENTER to continue..."; }

# ───────────────────────────────────────────────
# Main Menu
menu_mode() {
    while true; do
        clear
        echo -e "${GREEN}=== CN45 SECURITY TOOLKIT ===${RESET}"
        echo
        echo "  1) Optimize System"
        echo "  2) Full Hardener + Firewall"
        echo "  3) Scan System"
        echo "  4) Fix Pacman DB Lock"
        echo "  5) AUR Malware Scan"
        echo "  0) Exit"
        echo

        read -rp "Choose option: " opt
        case "$opt" in
            1) run_optimize ;;
            2) secure_mode ;;
            3) scan_mode ;;
            4) fix_pacman_lock ;;
            5) aurmc --full ;;
            0) echo "Exiting..."; exit 0 ;;
            *) warn "Invalid option." ;;
        esac

        pause
    done
}
