#!/usr/bin/env bash
# /* https://github.com/Suparman45 */
# Function: refresh

run_refresh() {
       # Kill app
      ${PREFIX}-kill --app $APP_OSD
      ${PREFIX}-kill --app $APP_LAUNCH
      ${PREFIX}-kill --app $APP_BAR
      ${PREFIX}-kill --app $APP_DOCK
      ${PREFIX}-kill --window

      sleep 1

       # Reload
       hyprctl reload
       ${PREFIX}-run start ctrl-need-start

}
