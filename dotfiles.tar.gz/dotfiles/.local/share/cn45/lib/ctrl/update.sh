#!/usr/bin/env bash
# /* https://github.com/Suparman45 */
# Update Modules

# --------------------------------------------------------------
# CONFIG
# --------------------------------------------------------------
TH_YELLOW=10
TH_RED=30
ICON="󰏗"

# --------------------------------------------------------------
# Detect AUR helper
# --------------------------------------------------------------
detect_helper() {
    if command -v paru >/dev/null 2>&1; then
        echo "paru"
    elif command -v yay >/dev/null 2>&1; then
        echo "yay"
    else
        echo "pacman"
    fi
}

# --------------------------------------------------------------
# WAYBAR JSON OUTPUT
# --------------------------------------------------------------
get_sys_json() {
    local TOTAL CLASS

    TOTAL=$(checkupdates 2>/dev/null | wc -l)

    CLASS="green"
    (( TOTAL >= TH_YELLOW )) && CLASS="yellow"
    (( TOTAL >= TH_RED )) && CLASS="red"

    printf '{ "text": "%s %d", "class": "%s", "tooltip": "System updates: %d" }\n' \
        "$ICON" "$TOTAL" "$CLASS" "$TOTAL"
}

# --------------------------------------------------------------
# FULL SYSTEM UPDATE (CLICK ACTION)
# --------------------------------------------------------------
get_sys_update() {
    local PM LOCKFILE="/var/lib/pacman/db.lck"

    PM=$(detect_helper)

    while [[ -f "$LOCKFILE" ]]; do
        sleep 1
    done

    ${PREFIX}-run -s a "$APP_TERM" -e sudo "$PM" -Syu
}
