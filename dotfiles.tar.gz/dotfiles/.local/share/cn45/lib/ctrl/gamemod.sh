#!/usr/bin/env bash
# /* https://github.com/Suparman45 */
# Game mode module

GAMEMODE_STATE="$CN45_STATE_DIR/gamemode.state"

_run_gamemode_on() {

    # =========================
    # ENABLE GAMEMODE
    # =========================
    hyprctl -q --batch "\
        keyword animations:enabled 0;\
        keyword decoration:shadow:enabled 0;\
        keyword decoration:blur:enabled 0;\
        keyword decoration:blur:xray 1;\
        keyword general:gaps_in 0;\
        keyword general:gaps_out 0;\
        keyword general:border_size 1;\
        keyword decoration:rounding 0;\
        keyword decoration:active_opacity 1;\
        keyword decoration:inactive_opacity 1;\
        keyword decoration:fullscreen_opacity 1;\
        keyword layerrule noanim,waybar;\
        keyword layerrule noanim,nwg-dock-hyprland;\
        keyword layerrule noanim,swaync-notification-window;\
        keyword layerrule noanim,awww-daemon;\
        keyword layerrule noanim,walker\
    "

    # Force windows opaque
    hyprctl keyword windowrulev2 "opacity 1 override 1 override,class:.*"

    # Stop wallpaper daemon
    pkill -x awww-daemon 2>/dev/null

    # CPU profile
    command -v profile_set >/dev/null && profile_set performance

    mkdir -p "$CN45_STATE_DIR"
    echo "1" > "$GAMEMODE_STATE"

    notify-send -t 2000 "⚡ Gamemode Enabled"
}

_run_gamemode_off() {

    # =========================
    # DISABLE GAMEMODE
    # =========================

    if command -v awww-daemon >/dev/null; then
        if ! pgrep -x awww-daemon >/dev/null; then
            awww-daemon --format xrgb &
        fi

        if [ -f "$CN45_STATE_DIR/.current_wallpaper" ]; then
            awww img "$CN45_STATE_DIR/.current_wallpaper"
        fi
    fi

    # reload config
    hyprctl reload

    # CPU profile
    command -v profile_set >/dev/null && profile_set balanced

    rm -f "$GAMEMODE_STATE"

    notify-send -t 2000 "⚖️ Gamemode Disabled"
}

run_gamemode() {

    mkdir -p "$CN45_STATE_DIR"

    # =========================
    # TOGGLE
    # =========================
    if [ -f "$GAMEMODE_STATE" ]; then
        _run_gamemode_off
    else
        _run_gamemode_on
    fi
}
