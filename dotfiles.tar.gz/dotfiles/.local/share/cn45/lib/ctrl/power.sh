#!/usr/bin/env bash
# /* https://github.com/Suparman45 */

# ==========================================
# CN45 Power Manager
# ==========================================

# Configuration
WALLPAPER_DIR="${WALL_DIR:-$HOME/Pictures/wallpapers}"
LOCK_DIR="${CN45_STATE_DIR:-$HOME/.local/state/cn45}"
LOCK_FILE="$LOCK_DIR/.lock_screen"

# Ensure lock directory exists
mkdir -p "$LOCK_DIR"


# Functions
power_off() {
   ${PREFIX}-log -w "Shutting down..."
   ${PREFIX}-kill --window
   systemctl poweroff
}

power_reboot() {
   ${PREFIX}-log -w "Reboot system..."
   ${PREFIX}-kill --window
   systemctl reboot
}

power_exit() {
    ${PREFIX}-log -w "Logging out..."
    ${PREFIX}-kill --window
    if uwsm check is-active; then
           uwsm stop
    else
           hyprctl dispatch exit 0
    fi
}

power_freeze() {
    ${PREFIX}-log -w "Hibernating system..."
    ${PREFIX}-kill --window
    systemctl hibernate
}

power_lock() {
    ${PREFIX}-log -w "Locking screen..."
    # Select a random wallpaper
    local wallpaper
    wallpaper=$(find "$WALLPAPER_DIR" -type f | shuf -n 1)

    if [[ -n "$wallpaper" ]]; then
        ln -sf "$wallpaper" "$LOCK_FILE"
        ${PREFIX}-log -s "Selected wallpaper: $wallpaper"
    else
        ${PREFIX}-log -e "No wallpapers found in $WALLPAPER_DIR"
    fi

    # Lock screen using hyprlock
    ${PREFIX}-RUN -s a hyprlock
}

power_sleep() {
    ${PREFIX}-log -w "Suspending system..."
    power_lock & disown && systemctl suspend
}
