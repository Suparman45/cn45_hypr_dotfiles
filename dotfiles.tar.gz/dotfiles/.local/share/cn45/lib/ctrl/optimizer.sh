#!/usr/bin/env bash
# https://github.com/Suparman45
# Pacman Cleaner + DB Lock Fixer (Terminal Only)

# ───────────────────────────────────────────────
# Colors
GREEN="\e[32m"; YELLOW="\e[33m"; BLUE="\e[36m"; RESET="\e[0m"

# ───────────────────────────────────────────────
# Check root
is_root() { [ "$(id -u)" -eq 0 ]; }

# ───────────────────────────────────────────────
# Log helpers
info()    { echo -e "${BLUE}[INFO]${RESET} $1"; }
success() { echo -e "${GREEN}[OK]${RESET}  $1"; }
error()   { echo -e "${YELLOW}[WARN]${RESET} $1"; }

confirm() {
    echo -ne "${YELLOW}?${RESET} $1 (y/N): "
    read -r answer
    [[ "$answer" =~ ^[Yy]$ ]]
}

# ───────────────────────────────────────────────
# Fix Pacman DB lock
fix_pacman_lock() {
    local lock="/var/lib/pacman/db.lck"

    if [[ -f "$lock" ]]; then
        info "Pacman DB lock detected."

        if confirm "Remove lock & kill pacman/pamac?"; then
            sudo pkill -9 pacman 2>/dev/null
            sudo pkill -9 pamac 2>/dev/null
            sudo rm -f "$lock"
            success "Pacman DB lock removed."
        else
            info "Skipped."
        fi
    else
        success "No DB lock found."
    fi
}

# ───────────────────────────────────────────────
# Cleaner
run_cleaner() {
    local mode="$1"

    info "Starting cleaning process…"

    info "Checking Pacman DB lock..."
    fix_pacman_lock

    info "Syncing package database..."
    if is_root; then
        pacman -Sy --noconfirm &>/dev/null
    else
        sudo pacman -Sy --noconfirm &>/dev/null
    fi

    info "Cleaning cache…"
    local cache="/var/cache/pacman/pkg"

    case "$mode" in
        aggressive)
            sudo pacman -Scc --noconfirm &>/dev/null
            ;;
        normal)
            sudo find "$cache" -type f -mtime +30 -delete
            ;;
    esac

    info "Removing orphan packages..."
    orphans=$(pacman -Qtdq 2>/dev/null)
    if [[ -n "$orphans" ]]; then
        sudo pacman -Rns --noconfirm $orphans &>/dev/null
    fi

    if [[ "$mode" == "journal" || "$mode" == "full" ]]; then
        info "Cleaning systemd journal..."
        sudo journalctl --vacuum-size=200M --vacuum-time=7d &>/dev/null
    fi

    info "Verifying package integrity..."
    sudo pacman -Qk &>/dev/null || true

    success "Cleaning completed!"
    echo -e "Pacman log: ${BLUE}/var/log/pacman.log${RESET}"
}

# ───────────────────────────────────────────────
# Terminal Menu
run_optimize() {
    clear
    while true; do
        clear
        echo -e "${GREEN}=== PACMAN MAINTENANCE TOOL ===${RESET}"
        echo ""
        echo "1) Dry-run (show actions only)"
        echo "2) Normal clean (cache >30 days & orphans)"
        echo "3) Aggressive clean (remove ALL cache)"
        echo "4) Clean systemd journal"
        echo "5) Full clean (all features)"
        echo "6) Fix Pacman DB lock"
        echo "0) Exit"
        echo ""
        echo -n "Choose an option: "
        read -r action

        case "$action" in
            0|"") exit 0 ;;
            1)
                echo -e "${BLUE}Dry-run:${RESET}
- Sync database
- Clean old cache
- Remove orphans
- Verify packages"
                ;;
            2) run_cleaner "normal" ;;
            3)
                if confirm "Remove ALL pacman cache?"; then
                    run_cleaner "aggressive"
                fi
                ;;
            4) run_cleaner "journal" ;;
            5)
                if confirm "Run full clean (all features)?"; then
                    run_cleaner "full"
                fi
                ;;
            6) fix_pacman_lock ;;
            *)
                error "Invalid option."
                ;;
        esac

        echo ""
        read -p "Press ENTER to return to the menu..."
    done
}

#!/bin/bash
# ───────────────────────────────────────────────
# Colors
GREEN="\e[32m"; YELLOW="\e[33m"; BLUE="\e[36m"; RESET="\e[0m"

# ───────────────────────────────────────────────
# Root check
is_root() { [ "$(id -u)" -eq 0 ]; }

# ───────────────────────────────────────────────
# Log helpers
info()    { echo -e "${BLUE}[INFO]${RESET} $1"; }
success() { echo -e "${GREEN}[OK]${RESET}  $1"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET} $1"; }

confirm() {
    echo -ne "${YELLOW}?${RESET} $1 (y/N): "
    read -r ans
    [[ "$ans" =~ ^[Yy]$ ]]
}

# ───────────────────────────────────────────────
# Fix Pacman DB lock
fix_pacman_lock() {
    local lock="/var/lib/pacman/db.lck"

    if [[ -f "$lock" ]]; then
        info "Pacman DB lock detected."
        if confirm "Remove lock and kill pacman/pamac processes?"; then
            sudo pkill -9 pacman 2>/dev/null
            sudo pkill -9 pamac 2>/dev/null
            sudo rm -f "$lock"
            success "Pacman DB lock removed."
        else
            info "Skipped."
        fi
    else
        success "No pacman DB lock found."
    fi
}

# ───────────────────────────────────────────────
# Cleaner logic
run_cleaner() {
    local mode="$1"

    info "Starting cleaning process…"

    info "Checking pacman DB lock…"
    fix_pacman_lock

    info "Syncing package database…"
    if is_root; then
        pacman -Sy --noconfirm &>/dev/null
    else
        sudo pacman -Sy --noconfirm &>/dev/null
    fi

    info "Cleaning pacman cache…"
    case "$mode" in
        aggressive)
            sudo pacman -Scc --noconfirm &>/dev/null
            ;;
        normal)
            sudo find /var/cache/pacman/pkg -type f -mtime +30 -delete
            ;;
    esac

    info "Removing orphan packages…"
    orphans=$(pacman -Qtdq 2>/dev/null)
    if [[ -n "$orphans" ]]; then
        sudo pacman -Rns --noconfirm $orphans &>/dev/null
    fi

    if [[ "$mode" == "journal" || "$mode" == "full" ]]; then
        info "Cleaning systemd journal…"
        sudo journalctl --vacuum-size=200M --vacuum-time=7d &>/dev/null
    fi

    info "Verifying package integrity…"
    sudo pacman -Qk &>/dev/null || true

    success "Cleaning completed!"
    echo -e "Pacman log available at: ${BLUE}/var/log/pacman.log${RESET}"
}

# ───────────────────────────────────────────────
# Inner menu (runs inside alacritty)
run_optimize_inner() {
    clear
    while true; do
        clear
        echo -e "${GREEN}=== PACMAN MAINTENANCE TOOL ===${RESET}"
        echo ""
        echo "1) Dry-run (show planned actions)"
        echo "2) Normal clean (cache > 30 days + orphans)"
        echo "3) Aggressive clean (remove ALL pacman cache)"
        echo "4) Clean systemd journal"
        echo "5) Full clean (all features)"
        echo "6) Fix pacman DB lock"
        echo "0) Exit"
        echo ""
        echo -n "Choose an option: "
        read -r option

        case "$option" in
            0|"") exit 0 ;;
            1)
                echo -e "${BLUE}Dry-run:${RESET}
- Sync package database
- Clean old cache
- Remove orphan packages
- Verify installed packages"
                ;;
            2) run_cleaner "normal" ;;
            3)
                if confirm "Are you sure you want to delete ALL pacman cache?"; then
                    run_cleaner "aggressive"
                fi
                ;;
            4) run_cleaner "journal" ;;
            5)
                if confirm "Run full clean with all features?"; then
                    run_cleaner "full"
                fi
                ;;
            6) fix_pacman_lock ;;
            *) warn "Invalid option." ;;
        esac

        echo ""
        read -p "Press ENTER to return to the menu..."
    done
}

# ───────────────────────────────────────────────
# Launch menu inside a new alacritty window
run_optimize() {
    # Kill previous alacritty session if exists
    if pgrep "$APP_TERM" > /dev/null; then
          ${PREFIX}-kill -a $APP_TERM
else
    # Export functions so subshell can access them
    export -f is_root info success warn confirm run_cleaner fix_pacman_lock run_optimize_inner

    # Run
    ${PREFIX}-run -s a $APP_TERM -e bash -c "run_optimize_inner"
fi
}


