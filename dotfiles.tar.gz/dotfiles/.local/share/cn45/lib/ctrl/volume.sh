#!/usr/bin/env bash
# /* https://github.com/Suparman45 */
# Volume Module

ICONS_PATH="$CN45_CONFIG_DIR/assets/icons"

# --- Helper functions ---
get_sink_output() { wpctl get-volume @DEFAULT_SINK@ 2>/dev/null; }
get_source_output() { wpctl get-volume @DEFAULT_SOURCE@ 2>/dev/null; }
get_mic_id() { wpctl status | grep -A3 "Sources:" | grep -oP '\[\K[0-9]+(?=\])' | head -n 1; }

# --- Independent controls ---
inc_volume() { wpctl set-volume -l 1.3 @DEFAULT_SINK@ 5%+ && notify_volume; }
dec_volume() { wpctl set-volume @DEFAULT_SINK@ 5%- && notify_volume; }
toggle_mute() { wpctl set-mute @DEFAULT_SINK@ toggle && notify_volume; }

inc_mic_volume() {
    local mic_id=$(get_mic_id)
    [[ -z "$mic_id" ]] && notify_mic && return
    wpctl set-volume -l 1.3 @DEFAULT_SOURCE@ 5%+ && notify_mic
}
dec_mic_volume() {
    local mic_id=$(get_mic_id)
    [[ -z "$mic_id" ]] && notify_mic && return
    wpctl set-volume @DEFAULT_SOURCE@ 5%- && notify_mic
}
toggle_mic() {
    local mic_id muted
    mic_id=$(get_mic_id)
    [[ -z "$mic_id" ]] && notify_mic && return

    muted=$(wpctl get-volume @DEFAULT_SOURCE@ | grep -o "MUTED")
    [[ "$muted" == "MUTED" ]] && wpctl set-mute @DEFAULT_SOURCE@ 0 || wpctl set-mute @DEFAULT_SOURCE@ 1
    notify_mic
}

# --- Notification helpers ---
notify_volume() {
    local vol muted
    vol=$(get_volume)
    muted=$(wpctl get-volume @DEFAULT_SINK@ | grep -o "MUTED")

    if [[ "$muted" == "MUTED" || "$vol" -eq 0 ]]; then
        notify-send -e -i "$ICONS_PATH/volume-mute.png" -u low "Speaker" "Muted"
    else
        notify-send -e -i "$ICONS_PATH/volume-high.png" -u low "Speaker Volume" "${vol}%"
    fi
}

notify_mic() {
    local mic_id vol muted
    mic_id=$(get_mic_id)

    [[ -z "$mic_id" ]] && {
        # Mic tidak ada → tampilkan symbol mute, tapi jangan set-mute
        notify-send -e -i "$ICONS_PATH/microphone-mute.png" -u low "Microphone" "No Mic Detected"
        return
    }

    vol=$(get_mic_volume)
    muted=$(wpctl get-volume @DEFAULT_SOURCE@ | grep -o "MUTED")
    if [[ "$muted" == "MUTED" || "$vol" -eq 0 ]]; then
        notify-send -e -i "$ICONS_PATH/microphone-mute.png" -u low "Microphone" "Muted"
    else
        notify-send -e -i "$ICONS_PATH/microphone.png" -u low "Microphone Volume" "${vol}%"
    fi
}

# --- Volume getters ---
get_volume() {
    local out
    out=$(get_sink_output)
    [[ -z "$out" ]] && echo 0 && return
    echo "$out" | awk '{print int($2 * 100)}'
}

get_mic_volume() {
    local mic out
    mic=$(get_mic_id)
    [[ -z "$mic" ]] && echo 0 && return
    out=$(get_source_output)
    [[ -z "$out" ]] && echo 0 && return
    echo "$out" | awk '{print int($2 * 100)}'
}

# --- JSON Output ---
get_volume_json() {
    local vol muted text
    vol=$(get_volume)
    muted=$(wpctl get-volume @DEFAULT_SINK@ | grep -o "MUTED")

    if [[ "$muted" == "MUTED" || "$vol" -eq 0 ]]; then
        text="󰖁"
    elif [[ "$vol" -le 30 ]]; then
        text=" ${vol}%"
    elif [[ "$vol" -le 60 ]]; then
        text=" ${vol}%"
    elif [[ "$vol" -le 85 ]]; then
        text="󰕾 ${vol}%"
    else
        text=" ${vol}%"
    fi

    printf '{"icon":"󰕾","text":"%s"}\n' "$text"
}

get_mic_json() {
    local mic_id vol muted text
    mic_id=$(get_mic_id)

    if [[ -z "$mic_id" ]]; then
        printf '{"icon":"","text":""}\n'
        return
    fi

    vol=$(get_mic_volume)
    muted=$(wpctl get-volume @DEFAULT_SOURCE@ | grep -o "MUTED")
    [[ "$muted" == "MUTED" || "$vol" -eq 0 ]] && text="" || text=" ${vol}%"
    printf '{"icon":"","text":"%s"}\n' "$text"
}
