#!/usr/bin/env bash
# /* https://github.com/Suparman45 */

# Main dispatcher

flag="${1:-}"
target="${2:-}"

case "$flag" in
    --refresh)    run_refresh ;;
    --gamod)    run_gamemode ;;
    --upd)
       case "$target" in
         sys)    get_sys_update ;;
         json)  get_sys_json ;;
       esac
    ;;
        --brightness|-b)
        case "$target" in
            get) get_brightness ;;
            inc)  change_brightness "$step" ;;
            dec) change_brightness "-$step" ;;
            *)     get_brightness ;;
      esac
   ;;
    --power|-p)
        case "$target" in
            off)                     power_off ;;
            exit)                   power_exit ;;
            sleep)                power_sleep ;;
            reboot)             power_reboot ;;
            freeze)              power_freeze ;;
            lock)                  power_lock ;;
            prof-faster)      profile_set performance ;;
            prof-balance)  profile_set balanced ;;
            prof-saver)       profile_set power-saver ;;
            prof-toggle)     profile_set toggle ;;
            prof-auto)        profile_set auto ;;
            prof-status)     profile_set status ;;
            *)
                ${PREFIX}-log -e "Unknown module: $target 🗿"
                ;;
        esac
    ;;

    --volume|-v)
        case "$target" in
            get-json)          get_volume_json ;;
            get-json-mic)  get_mic_json ;;
            inc)                   inc_volume ;;
            dec)                 dec_volume ;;
            toggle)            toggle_mute ;;
            mic-inc)          inc_mic_volume ;;
            mic-dec)        dec_mic_volume ;;
            toggle-mic)   toggle_mic ;;
            *)                    get_volume_json ;;
        esac
    ;;

    *)
        ${PREFIX}-log -e "Unknown module: $target 🗿"
    ;;
esac
