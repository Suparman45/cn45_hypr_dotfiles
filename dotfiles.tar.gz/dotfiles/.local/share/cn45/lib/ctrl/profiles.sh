#!/usr/bin/env bash
# /* https://github.com/Suparman45 */

# Color definitions
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
RED="\033[1;31m"
CYAN="\033[1;36m"
NC="\033[0m"

# Profile set function
profile_set() {
    local PROFILE="$1"

    # normalize only for command matching (not for output/${PREFIX}-log -s)
    local CMD=$(echo "$PROFILE" | tr '[:upper:]' '[:lower:]')

    if ! command -v powerprofilesctl &>/dev/null; then
        ${PREFIX}-log -e "${RED}❌ powerprofilesctl not found!${NC}"
        return 1
    fi

    case "$CMD" in
        performance)
            powerprofilesctl set performance
            ${PREFIX}-log -s "${GREEN}⚡ Power profile set to performance${NC}"
            ;;
        balanced)
            powerprofilesctl set balanced
            ${PREFIX}-log -s "${YELLOW}⚖️  Power profile set to balanced${NC}"
            ;;
        power-saver | saver)
            powerprofilesctl set power-saver
            ${PREFIX}-log -s "${CYAN}🔋 Power profile set to power-saver${NC}"
            ;;
        toggle)
            local CURRENT
            CURRENT=$(powerprofilesctl get)
            case "$CURRENT" in
                performance)
                    powerprofilesctl set balanced
                    ${PREFIX}-log -s "${YELLOW}⚖️  Switched to balanced${NC}"
                    ;;
                balanced)
                    powerprofilesctl set power-saver
                    ${PREFIX}-log -s "${CYAN}🔋 Switched to power-saver${NC}"
                    ;;
                *)
                    powerprofilesctl set performance
                    ${PREFIX}-log -s "${GREEN}⚡ Switched to performance${NC}"
                    ;;
            esac
            ;;
        auto)
            local AC_STATUS
            AC_STATUS=$(cat /sys/class/power_supply/AC/online 2>/dev/null || echo 1)
            if [ "$AC_STATUS" -eq 1 ]; then
                powerprofilesctl set performance
                ${PREFIX}-log -s "${GREEN}⚡ Auto mode: AC connected → performance${NC}"
            else
                powerprofilesctl set power-saver
                ${PREFIX}-log -s "${CYAN}🔋 Auto mode: on battery → power-saver${NC}"
            fi
            ;;
        status)
            local CURRENT
            CURRENT=$(powerprofilesctl get)
            ${PREFIX}-log -s "📊 Current power profile: ${YELLOW}$CURRENT${NC}"
            ;;
        *)
            echo -e "${RED}Usage:${NC} profile_set {performance|balanced|power-saver|toggle|auto|status}"
            return 1
            ;;
    esac

    # Desktop notification
    if command -v notify-send &>/dev/null; then
        notify-send -t 5000 "⚙️ Mode: $(powerprofilesctl get)"
    fi
}

