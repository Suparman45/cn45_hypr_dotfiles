#!/usr/bin/env bash
# /* https://github.com/Suparman45 */
# Argument handler

flag="${1:-}"
target="${2:-}"

case "$flag" in
    start)
        case "$target" in
            # Autostart modules
            autorun)
                ${PREFIX}-env --import
                ${PREFIX}-env --update
                ${PREFIX}-env --export
                ${PREFIX}-env --polkit
                ${PREFIX}-extend --sw
                ${PREFIX}-extend --plugins
                ${PREFIX}-extend --gtk
                ${PREFIX}-extend --cursor
                ${PREFIX}-extend --cliphist
                ${PREFIX}-extend --fcitx
                ${PREFIX}-extend --tray
                ${PREFIX}-app --uterm srv
                ${PREFIX}-run -t service -s a $APP_OSD
                ${PREFIX}-run -t service -s b $APP_IDLE
                ${PREFIX}-run -t service -s b $APP_SUNSET
                ${PREFIX}-bar --dock
                ${PREFIX}-bar --top
                ;;

            ctrl-need-start)
                ${PREFIX}-run -t service -s a $APP_OSD
                ${PREFIX}-extend --cursor
                ${PREFIX}-bar --dock
                ${PREFIX}-bar --top
                ;;

            # Launch apps
            term)        ${PREFIX}-app --uterm  run  ;;
            drawer)    ${PREFIX}-launcher --draw ;;
            launcher) ${PREFIX}-launcher --search ;;
            fileman)   ${PREFIX}-run -s a $APP_FILEMAN ;;
            browser)  ${PREFIX}-run -s a $APP_BROWSER ;;
            editor)      ${PREFIX}-run -s a $APP_USER_EDITOR ;;
            mrom)      ${PREFIX}-run -s a $APP_ROMMON ;;
            mram)      ${PREFIX}-run -s a $APP_TERM -e $APP_RAMMON ;;
            nmui)        ${PREFIX}-run -s a $APP_NMCUI || ${PREFIX}-run -s a $APP_TERM -e $APP_NMTUI ;;
            calendar)  ${PREFIX}-app --calendar ;;
            *)
                ${PREFIX}-log -e "Unknown module: $target 🗿"
                ;;
        esac
        ;;

    -e|--edit)
        ${PREFIX}-run -T $APP_EDITOR "$target"
        ;;

    *)
        if ! source "app2unit.sh"; then
            ${PREFIX}-log -e "[FATAL] Failed to source app2unit.sh" >&2
            exit 1
        fi
        ;;
esac
