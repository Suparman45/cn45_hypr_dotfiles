#!/usr/bin/env bash
# /* https://github.com/Suparman45 */
# Function: System environment handlers

cn45-env() {
    case "$1" in
        --import)
            ${PREFIX}-log -s "🌐 Importing environment..."
            dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_CURRENT_DESKTOP >/dev/null 2>&1
            ;;

        --update)
           ${PREFIX}-log -s  "🔄 Updating XDG portals..."
            systemctl --user import-environment WAYLAND_DISPLAY XDG_CURRENT_DESKTOP >/dev/null 2>&1
            ;;

        --export)
           ${PREFIX}-log -s  "📤 Exporting environment..."
            uwsm finalize >/dev/null 2>&1
            ;;

        --polkit)
            polkit_agents=(
                "/usr/lib/polkit-gnome/polkit-gnome-authentication-agent-1"
                "/usr/libexec/hyprpolkitagent"
                "/usr/lib/hyprpolkitagent"
                "/usr/lib/hyprpolkitagent/hyprpolkitagent"
                "/usr/lib/polkit-kde-authentication-agent-1"
                "/usr/libexec/polkit-gnome-authentication-agent-1"
                "/usr/libexec/polkit-mate-authentication-agent-1"
                "/usr/lib/x86_64-linux-gnu/libexec/polkit-kde-authentication-agent-1"
                "/usr/lib/policykit-1-gnome/polkit-gnome-authentication-agent-1"
            )

            POLKIT_AGENT=""
            for file in "${polkit_agents[@]}"; do
                if [ -x "$file" ]; then
                    POLKIT_AGENT="$file"
                   ${PREFIX}-log -s  "✅ Polkit agent found: $POLKIT_AGENT"
                    break
                fi
            done

            if [ -z "$POLKIT_AGENT" ]; then
               ${PREFIX}-log -e  "⚠️  No valid Polkit agent found. Please install one."
            else
                ${PREFIX}-run -t service  "$POLKIT_AGENT"
            fi
            ;;

        *)
           ${PREFIX}-log -e  "❌ Unknown environment flag 🗿"
            ;;
    esac
}

