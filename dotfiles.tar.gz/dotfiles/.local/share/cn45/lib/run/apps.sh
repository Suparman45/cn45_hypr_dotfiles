#!/usr/bin/env bash
# /* https://github.com/Suparman45 */
# Universal YAD Calendar

cn45-app() {
    case "$1" in
        --calendar)
            if pgrep -x yad >/dev/null; then
                ${PREFIX}-kill -a yad
            else
                ${PREFIX}-run yad \
                    --calendar \
                    --title="Calendar" \
                    --date-format="%Y-%m-%d" \
                    --width=1200 \
                    --height=800 \
                    --undecorated \
                    --skip-taskbar \
                    --no-buttons \
                    --window-icon="calendar"
            fi
            ;;

        --uterm)
            case "$2" in
                run)
                    if [[ "$APP_USER_TERM" == "foot" ]]; then
                        ${PREFIX}-run -s a footclient
                    else
                        ${PREFIX}-run -s a "$APP_USER_TERM"
                    fi
                    ;;

                srv)
                    if [[ "$APP_USER_TERM" == "foot" ]]; then
                        ${PREFIX}-run -t service -s b foot --server &
                        ${PREFIX}-log -s "Foot daemon has launched" &
                    else
                        ${PREFIX}-log -w "Default user terminal is not foot"
                    fi
                    ;;
            esac
            ;;
    esac
}


