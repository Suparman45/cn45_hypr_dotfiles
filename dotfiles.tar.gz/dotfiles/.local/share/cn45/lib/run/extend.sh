#!/usr/bin/env bash
# /* https://github.com/Suparman45 */
# Function: Extended loaders (GTK, Cursor, Plugins, Dock)

cn45-extend() {
    local gtk3_conf="$HOME/.config/gtk-3.0/settings.ini"
    local gtk4_conf="$HOME/.config/gtk-4.0/settings.ini"
    local cursor_conf="$HOME/.icons/default/index.theme"

    case "$1" in
        --gtk)
            local color_scheme="prefer-dark"
            local gtk_theme icon_theme cursor_theme

            # 🔍  GTK config
            if [ -f "$gtk3_conf" ]; then
                ${PREFIX}-log -w "🎨 Loading GTK3 configuration..."
                gtk_theme=$(grep -E '^gtk-theme-name=' "$gtk3_conf" | cut -d'=' -f2 | tr -d '"')
                icon_theme=$(grep -E '^gtk-icon-theme-name=' "$gtk3_conf" | cut -d'=' -f2 | tr -d '"')
                cursor_theme=$(grep -E '^gtk-cursor-theme-name=' "$gtk3_conf" | cut -d'=' -f2 | tr -d '"')
            elif [ -f "$gtk4_conf" ]; then
                ${PREFIX}-log -w "🎨 Loading GTK4 configuration..."
                gtk_theme=$(grep -E '^gtk-theme-name=' "$gtk4_conf" | cut -d'=' -f2 | tr -d '"')
                icon_theme=$(grep -E '^gtk-icon-theme-name=' "$gtk4_conf" | cut -d'=' -f2 | tr -d '"')
                cursor_theme=$(grep -E '^gtk-cursor-theme-name=' "$gtk4_conf" | cut -d'=' -f2 | tr -d '"')
            else
                ${PREFIX}-log -e "⚠️  No GTK config found, skipping..."
                return 0
            fi

            # 🖌️ Set to sistem via gsettings
            if ! command -v gsettings >/dev/null 2>&1; then
                ${PREFIX}-log -e "❌ gsettings not found — skipping GTK apply"
                return 1
            fi

            ${PREFIX}-log -w "🖌️ Applying GTK settings via gsettings..."
            {
                ${PREFIX}-run -t service -s s gsettings set org.gnome.desktop.interface color-scheme "$color_scheme"
                ${PREFIX}-run -t service -s s gsettings set org.gnome.desktop.interface gtk-theme "$gtk_theme"
                ${PREFIX}-run -t service -s s gsettings set org.gnome.desktop.interface icon-theme "$icon_theme"
                ${PREFIX}-run -t service -s s gsettings set org.gnome.desktop.interface cursor-theme "$cursor_theme"
                ${PREFIX}-run -t service -s s gsettings set org.gnome.desktop.interface cursor-size 24
            } >/dev/null 2>&1 &

            ${PREFIX}-log -s "✅ GTK applied → Theme: $gtk_theme | Icon: $icon_theme | Cursor: $cursor_theme (Dark mode)"
            ;;

        --cursor)
            local XCURSOR_THEME XCURSOR_SIZE

            if [ -f "$cursor_conf" ]; then
                ${PREFIX}-log -w "🖱️ Loading cursor configuration..."
                XCURSOR_THEME=$(grep -E '^Inherits=' "$cursor_conf" | cut -d'=' -f2 | tr -d '"')
                XCURSOR_SIZE=${CURSOR_SIZE:-24}
            elif [ -f "$gtk3_conf" ]; then
                XCURSOR_THEME=$(grep -E '^gtk-cursor-theme-name=' "$gtk3_conf" | cut -d'=' -f2 | tr -d '"')
                XCURSOR_SIZE=$(grep -E '^gtk-cursor-theme-size=' "$gtk3_conf" | cut -d'=' -f2 | tr -d '"')
            else
                ${PREFIX}-log -e "⚠️  No cursor config found, skipping..."
                return 0
            fi

            if command -v hyprctl >/dev/null 2>&1; then
                hyprctl setcursor "$XCURSOR_THEME" "${XCURSOR_SIZE:-24}" >/dev/null 2>&1
                ${PREFIX}-log -s "✅ Cursor applied → Theme: $XCURSOR_THEME (${XCURSOR_SIZE:-24})"
            else
                ${PREFIX}-log -e "⚠️  hyprctl not found, skipping cursor apply"
            fi
            ;;

        --plugins)
            if [[ "$SET_HYPRPM" == "ON" ]]; then
                ${PREFIX}-log -w "🔁 Reloading Hyprland plugins..."
                hyprpm reload >/dev/null 2>&1
                ${PREFIX}-log -s "✅ Plugins reloaded."
            else
                ${PREFIX}-log -e "⚠️  hyprpm is off, skipping..."
            fi
            ;;

        --sw)
           local MONITOR
           MONITOR=$(detect_monitor)

           if [[ "$APP_WALL_SERVICE" == "awww" ]]; then
                ${PREFIX}-log -s "🖼️  Loading wallpaper success"
                ${PREFIX}-run -t service -s b awww-daemon --format xrgb &
                ${PREFIX}-run -s b awww img $CN45_STATE_DIR/.current_wallpaper &
           elif [[ "$APP_WALL_SERVICE" == "mpvpaper" ]]; then
                ${PREFIX}-log -s "🖼️  Loading wallpaper success"
                ${PREFIX}-run -s b mpvpaper $MONITOR $CN45_STATE_DIR/.current_wallpaper --no-audio --loop
           else
                ${PREFIX}-log -e "Wallpaper service not set"
           fi
            ;;

        --cliphist)
                if [[ "$SET_CLIPHIST" == "ON" ]]; then
                    ${PREFIX}-run -t service -s b  wl-paste --type text --watch cliphist store &
                    ${PREFIX}-run -t service -s b wl-paste --type image --watch cliphist store &
                else
                    ${PREFIX}-log -w "Cliphist: OFF"
                 fi
            ;;

        --fcitx)
                 if [[ "$SET_FCITX" == "ON" ]]; then
                     ${PREFIX}-run -t service -s b fcitx5 -d &
                else
                     ${PREFIX}-log -w "Fcitx: OFF"
                 fi
            ;;

        --tray)
                if [[ "$SET_TRAY" == "ON" ]]; then
                    ${PREFIX}-run -t service -s b nm-applet --indicator &
                else
                    ${PREFIX}-log -w "Tray: OFF"
               fi
             ;;

        *)
            ${PREFIX}-log -e "❌ Unknown run_ext flag: '$1'"
            ;;
    esac
}


