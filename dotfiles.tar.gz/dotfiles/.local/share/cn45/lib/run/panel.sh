#!/usr/bin/env bash
# Launcher Modules

# Bar
cn45-bar() {
    case "$1" in
          --top) ${PREFIX}-run -t service -s a $APP_BAR ;;

          --dock)
        if [[ "$APP_DOCK" == "nwg-dock-hyprland" ]]; then
                ${PREFIX}-log -s "📦 Launching Dock"
              if [[ "$SET_DOCK_AUTO_HIDE" == "OFF" ]]; then
                ${PREFIX}-run -t service -s s -- nwg-dock-hyprland \
                    -i 32 -w 5 -mb 10 -x -s style.css \
                    -c "${PREFIX}-run start drawer"
             elif [[ "$SET_DOCK_AUTO_HIDE" == "ON" ]]; then
                ${PREFIX}-run -t service -s s -- nwg-dock-hyprland \
                    -d -i 32 -w 5 -mb 10 -x -s style.css \
                    -c "${PREFIX}-run start drawer"
             else
                  ${PREFIX}-log -w "🗿"
             fi
        else
                ${PREFIX}-log -e "Dock not found"
        fi
            ;;
    esac
}

# Launcher
cn45-launcher() {
    case "$1" in
       --search)
            if [[ "$APP_LAUNCH" == "walker" ]]; then
                if pgrep "elephant" > /dev/null; then
                    ${PREFIX}-log -w  "🐘 Elephant is running.." >&2
                else
                    ${PREFIX}-log -w  "🐘 Elephant is NOT running, launching..." >&2
                    ${PREFIX}-run -s b elephant &
                fi

                if pgrep "walker" > /dev/null; then
                ${PREFIX}-kill -a walker
                else
                ${PREFIX}-run -s a walker
                fi

            else ${PREFIX}-log -e  "Error or launcher not installed"
            fi
            ;;

       --draw)
          if [[ "$SET_DRAWER" == "ON" ]]; then
                 if pgrep "nwg-drawer" > /dev/null; then
                 ${PREFIX}-kill -a nwg-drawer
                 else
                 ${PREFIX}-run -s a -- nwg-drawer -mb 10 -mr 400 -ml 400 -mt 10
                 fi
          elif [[ "$SET_DRAWER" == "OFF" ]]; then
                cn45-launcher --search

            else
                ${PREFIX}-log -w  "Drawer or launcher not installed"
            fi
            ;;

     *) ${PREFIX}-log -e  "🗿 Cukkkk" ;;
     esac
    }
