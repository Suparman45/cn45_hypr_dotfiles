#!/usr/bin/env bash
# =============================================================================
# CN45 Core - Clean & Simplified
# https://github.com/Suparman45
# =============================================================================

set -o errexit
set -o nounset
set -o pipefail

# ----------------------------
# Source Detection
# ----------------------------
_is_sourced() {
    [[ "${BASH_SOURCE[0]}" != "$0" ]]
}

_safe_fail() {
    local code="${1:-1}"
    local msg="${2:-}"

    [[ -n "$msg" ]] && cn45-log -e "$msg"

    if _is_sourced; then
        return "$code"
    else
        exit "$code"
    fi
}

# ----------------------------
# Security: Require PREFIX
# ----------------------------
EXPECTED_PREFIX="${EXPECTED_PREFIX:-cn45}"
PREFIX="${PREFIX:-}"

if [[ "$PREFIX" != "$EXPECTED_PREFIX" ]]; then
    _safe_fail 1 "PREFIX not set correctly! Script execution blocked for safety."
fi

# ----------------------------
# XDG Base Paths
# ----------------------------
export XDG_CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"
export XDG_LOCAL_HOME="${XDG_LOCAL_HOME:-$HOME/.local}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$HOME/.cache}"

# CN45 Structure
export CN45_CACHE_DIR="${CN45_CONFIG_DIR:-$XDG_CONFIG_HOME/cn45}"
export CN45_CACHE_DIR="${CN45_CACHE_DIR:-$XDG_CACHE_HOME/cn45}"
export CN45_DATA_DIR="${CN45_DATA_DIR:-$XDG_LOCAL_HOME/share/cn45}"
export CN45_STATE_DIR="${CN45_STATE_DIR:-$XDG_LOCAL_HOME/state/cn45}"

# Image Paths
export WALL_DIR="${WALL_DIR:-$HOME/Pictures/Screenshots}"
export MPV_DIR="${MPV_DIR:-$HOME/Videos/mpvpapers}"

# Runtime paths
export _RUN_DIR="$CN45_DATA_DIR/lib/run"
export _LOOK_DIR="$CN45_DATA_DIR/lib/look"
export _CTRL_DIR="$CN45_DATA_DIR/lib/ctrl"

# -------------------------------
# Loging configuration
# -------------------------------
CN45_LOG_DIR="$CN45_STATE_DIR/log"
CN45_LOG_FILE="$CN45_LOG_DIR/cn45.INFO.log"
CN45_LOG_MAX_SIZE=$((5 * 1024 * 1024))
DEBUG="${DEBUG:-1}"
CN45_DEBUG_STATUS=1

# -------------------------------
# Secure environment
# -------------------------------
umask 077
mkdir -p "$CN45_LOG_DIR"
chmod 700 "$CN45_LOG_DIR"

# -------------------------------
# Ensure log files exist
# -------------------------------
for lvl in INFO WARN ERROR SUCCESS DEBUG; do
    touch "$CN45_LOG_DIR/cn45.$lvl.log"
    chmod 600 "$CN45_LOG_DIR/cn45.$lvl.log"
done

# -------------------------------
# Portable file size detection
# -------------------------------
_cn45_file_size() {
    stat -c%s "$1" 2>/dev/null \
    || stat -f%z "$1" 2>/dev/null \
    || echo 0
}

# -------------------------------
# Log rotation by size
# -------------------------------
_cn45_log_rotate() {
    local file="$1"
    [[ -f "$file" ]] || return 0

    local size
    size="$(_cn45_file_size "$file")"

    if (( size >= CN45_LOG_MAX_SIZE )); then
        mv "$file" "$file.$(date '+%Y%m%d_%H%M%S')"
        touch "$file"
        chmod 600 "$file"
    fi
}

# -------------------------------
# Core logger (prepend style)
# -------------------------------
_cn45_log_base() {
    local level="$1"
    local color="$2"
    local msg="$3"
    local ts line tmp levelfile

    ts="$(date '+%Y-%m-%d %H:%M:%S')"
    line="[$ts] $level: $msg"

    if [[ "$level" != "DEBUG" || "$DEBUG" == "1" ]]; then
        printf '\033[1;%sm%s\033[0m\n' "$color" "$line" >&2
    fi

    _cn45_log_rotate "$CN45_LOG_FILE"
    tmp="$(mktemp "$CN45_LOG_DIR/.tmp.XXXXXX")"   # FIX
    {
        printf '%s\n' "$line"
        cat "$CN45_LOG_FILE"
    } > "$tmp"
    mv "$tmp" "$CN45_LOG_FILE"
    chmod 600 "$CN45_LOG_FILE"

    if [[ "$level" != "INFO" ]]; then
        levelfile="$CN45_LOG_DIR/cn45.$level.log"
        _cn45_log_rotate "$levelfile"
        tmp="$(mktemp "$CN45_LOG_DIR/.tmp.XXXXXX")"  # FIX
        {
            printf '%s\n' "$line"
            cat "$levelfile"
        } > "$tmp"
        mv "$tmp" "$levelfile"
        chmod 600 "$levelfile"
    fi

    if [[ "$CN45_DEBUG_STATUS" == "1" ]]; then
        if [[ "$level" == "WARN" || "$level" == "ERROR" ]]; then
            local debugfile="$CN45_LOG_DIR/cn45.DEBUG.log"
            _cn45_log_rotate "$debugfile"
            tmp="$(mktemp "$CN45_LOG_DIR/.tmp.XXXXXX")"
            {
                printf '%s\n' "[AUTO-DEBUG][$level] $line"
                cat "$debugfile"
            } > "$tmp"
            mv "$tmp" "$debugfile"
            chmod 600 "$debugfile"

            if [[ "$DEBUG" == "1" ]]; then
                printf '\033[1;90m%s\033[0m\n' \
                    "[AUTO-DEBUG][$level] $line" >&2
            fi
        fi
    fi
}

# -------------------------------
# Public logging API
# -------------------------------
cn45-log() {
    local level="$1"; shift
    case "$level" in
        -i) _cn45_log_base "INFO"    34 "$*" ;;
        -w) _cn45_log_base "WARN"    33 "$*" ;;
        -e) _cn45_log_base "ERROR"   31 "$*" ;;
        -s) _cn45_log_base "SUCCESS" 32 "$*" ;;
        *)  _cn45_log_base "WARN"    33 "Unknown log level: $level" ;;
    esac
}

# -------------------------------
# Fatal exit helper
# -------------------------------
cn45-die() {
    _cn45_log_base "ERROR" 31 "$*"
    if declare -F _safe_fail >/dev/null 2>&1; then
        _safe_fail 1
    else
        exit 1
    fi
}

# ----------------------------
# Config File
# ----------------------------
CONFIG_FILE="$CN45_CONFIG_DIR/configs.toml"
[[ -f "$CONFIG_FILE" ]] || cn45-die "Config file not found: $CONFIG_FILE"

# ----------------------------
# Load TOML Section
# ----------------------------
_cn45_load_section() {
    local section="$1"
    local prefix="$2"
    local mode="${3:-silent}"

    local key value var inside=0 line

    [[ ! "$prefix" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] && \
        cn45-die "Invalid prefix: $prefix"

    while IFS= read -r line; do
        [[ "$line" =~ ^\[[[:space:]]*$section[[:space:]]*\] ]] && { inside=1; continue; }
        [[ $inside -eq 1 && "$line" =~ ^\[ ]] && break
        [[ $inside -eq 0 || -z "$line" || "$line" =~ ^# ]] && continue

        if [[ "$line" =~ ^([^=]+)=(.*)$ ]]; then
            key="$(xargs <<< "${BASH_REMATCH[1]}")"
            value="$(sed 's/^ *//;s/ *$//;s/^["'"'"']\|["'"'"']$//g' <<< "${BASH_REMATCH[2]}")"
            var="${prefix}_${key^^}"
            var="${var//-/_}"
            printf -v "$var" '%s' "$value"
            export "$var"
        fi
    done < "$CONFIG_FILE"
}

# ----------------------------
# Generic Module Loader
# ----------------------------
_cn45_load_modules() {
    local base_dir="$1"
    local label="$2"

    [[ -z "$base_dir" ]] && { cn45-log -e "[$label] DIR not set"; return 1; }
    [[ ! -d "$base_dir" ]] && { cn45-log -i "[$label] No modules directory"; return 0; }

    shopt -s nullglob
    for module in "$base_dir"/*.sh; do
        [[ "${module##*/}" == "case.sh" ]] && continue
        [[ -r "$module" ]] || continue
        cn45-log -i "[$label] Loading ${module##*/}"
        source "$module"
    done
    shopt -u nullglob

    cn45-log -s "[$label] Modules loaded"
}

# ----------------------------
# Loader Dispatcher
# ----------------------------
cn45-loader() {
    case "$1" in
        --modules) shift; _cn45_load_modules "$@" ;;
        --section) shift; _cn45_load_section "$@" ;;
        *) cn45-die "Unknown loader command: $1" ;;
    esac
}

# ----------------------------
# Kill Functions
# ----------------------------
_cn45_kill_window() {
    # Ensure required tools exist
    command -v hyprctl >/dev/null 2>&1 || {
        cn45-log -e "[KILL] hyprctl not found"
        return 1
    }
    command -v jq >/dev/null 2>&1 || {
        cn45-log -e "[KILL] jq not found"
        return 1
    }

    # Collect all window addresses
    local targets
    targets="$(hyprctl clients -j | jq -r '.[].address' 2>/dev/null || true)"

    if [[ -z "$targets" ]]; then
        cn45-log -w "[KILL] No windows to close"
        return 0
    fi

    # Gracefully close all windows
    printf '%s\n' "$targets" |
        xargs -r -I{} hyprctl dispatch closewindow address:{}

    cn45-log -i "[KILL] Closed all windows"

    # Return to workspace 1 (original behavior preserved)
    hyprctl dispatch workspace 1
}

_cn45_kill_app() {
    local app="${1:-}"

    if [[ -z "$app" ]]; then
        cn45-log -w "[KILL] No application specified"
        return 1
    fi

    cn45-log -i "[KILL] Stopping application: $app"

    # 1️⃣ Graceful termination (original behavior preserved)
    pkill -x "$app" 2>/dev/null || killall "$app" 2>/dev/null || true
    sleep 0.5

    # 2️⃣ Check if anything is still running
    if pgrep -f "$app" >/dev/null 2>&1; then
        cn45-log -w "[KILL] App still running, forcing kill: $app"

        # 3️⃣ Force kill ALL remaining processes
        pkill -9 -f "$app" 2>/dev/null || killall -9 "$app" 2>/dev/null || true
    else
        cn45-log -s "[KILL] Application stopped: $app"
        return 0
    fi

    # 4️⃣ Final verification
    if pgrep -f "$app" >/dev/null 2>&1; then
        cn45-log -e "[KILL] Failed to fully terminate: $app"
        return 1
    fi

    cn45-log -s "[KILL] Application fully terminated: $app"
}


cn45-kill() {
    case "$1" in
        --window)
            _cn45_kill_window
            ;;
        --app|-a)
            shift
            _cn45_kill_app "$@"
            ;;
        *)
            cn45-log -w "Unknown kill option: $1"
            ;;
    esac
}

# ----------------------------
# Monitor Detection
# ----------------------------
detect_monitor() {
    hyprctl monitors -j | jq -r '.[0].name' 2>/dev/null || echo "HDMI-A-1"
}

# ----------------------------
# Load Config Sections
# ----------------------------
cn45-loader --section "apps" "APP"
cn45-loader --section "settings" "SET"

# ----------------------------
# End
# ----------------------------
_is_sourced || exit 0
