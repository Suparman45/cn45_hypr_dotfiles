-- ==========================================================================
-- Hyprland Loader
-- https://github.com/Suparman45
-- ==========================================================================

-- ◆ Environment Path Resolution
local HOME = os.getenv("HOME") or ("/home/" .. (os.getenv("USER") or ""))
local CN45_DATA = os.getenv("CN45_DATA_DIR") or (HOME .. "/.local/share/cn45")
local PREFIX = os.getenv("PREFIX") or "/usr"

-- ◆ Helper: Safe Non-Blocking Module Import
local function safe_require(module_name)
local ok, err = pcall(require, module_name)
if not ok then
    io.stderr:write(string.format("[HyprLoader ERROR] Failed to load '%s': %s\n", module_name, err))
    end
    return ok
    end

    -- ◆ Dynamic Path Injection
    local config_path = CN45_DATA .. "/hypr/configs"
    package.path = config_path .. "/?.lua;" .. config_path .. "/?/init.lua;" .. package.path

    -- ◆ Dynamic Module Discovery (Replaces Wildcard require)
    local function load_all_configs()
    local handle = io.popen("find " .. string.format("%q", config_path) .. " -maxdepth 1 -type f -name '*.lua' -print 2>/dev/null")
    if not handle then return end

        for file_path in handle:lines() do
            local module_name = file_path:match("([^/]+)%.lua$")
            if module_name and module_name ~= "init" then
                safe_require(module_name)
                end
                end
                handle:close()
                end

                -- Load all configuration modules dynamically
                load_all_configs()

                -- ◆ Hyprland Autorun Event Handler
                if hl and type(hl.on) == "function" then
                    hl.on("hyprland.start", function()
                    local exec_cmd = PREFIX .. "-run start autorun"

                    if type(hl.exec_cmd) == "function" then
                        hl.exec_cmd(exec_cmd)
                        else
                            os.execute(exec_cmd .. " &")
                            end
                            end)
                    else
                        io.stderr:write("[HyprLoader WARN] Global 'hl' table not initialized.\n")
                        end
