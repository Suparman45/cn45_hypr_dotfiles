-- ==========================================================================
-- == Hyprland Keybinds Config
-- https://github.com/Suparman45
-- ==========================================================================

-- -----------------------------------------------------------------------------
-- ◆ VARIABLES
-- -----------------------------------------------------------------------------
local mainMod = "SUPER"

-- -----------------------------------------------------------------------------
-- ◆ CORE SYSTEM BINDS
-- -----------------------------------------------------------------------------
hl.bind(mainMod .. " + SHIFT + R", hl.dsp.exec_cmd("${PREFIX}-ctrl --refresh"))
hl.bind(mainMod .. " + SHIFT + G", hl.dsp.exec_cmd("${PREFIX}-ctrl --gamod"))
hl.bind(mainMod .. " + Q",         hl.dsp.window.close())
hl.bind(mainMod .. " + O",         hl.dsp.exec_cmd("${PREFIX}-secure"))
hl.bind(mainMod .. " + SHIFT + Q", hl.dsp.exec_cmd("${PREFIX}-ctrl --power exit"))
hl.bind(mainMod .. " + END",       hl.dsp.exec_cmd("pkill wlogout || ${PREFIX}-run -s a wlogout"))
hl.bind("ALT + CTRL + SPACE",     hl.dsp.window.float({ action = "toggle" }))

-- -----------------------------------------------------------------------------
-- ◆ FULLSCREEN CONTROLS
-- -----------------------------------------------------------------------------
hl.bind(mainMod .. " + F",         hl.dsp.window.fullscreen(0))
hl.bind(mainMod .. " + M",         hl.dsp.window.fullscreen(1))

-- -----------------------------------------------------------------------------
-- ◆ LAUNCHERS & SYSTEM UTILITIES
-- -----------------------------------------------------------------------------
hl.bind(mainMod .. " + D",          hl.dsp.exec_cmd("${PREFIX}-run start launcher"))
hl.bind(mainMod .. " + C",          hl.dsp.exec_cmd("${PREFIX}-ctrl --cmd"))
hl.bind(mainMod .. " + CTRL + G",   hl.dsp.exec_cmd("${PREFIX}-look -w gallery"))
hl.bind(mainMod .. " + CTRL + C",   hl.dsp.exec_cmd("${PREFIX}-look -w random"))
hl.bind(mainMod .. " + CTRL + LEFT",  hl.dsp.exec_cmd("${PREFIX}-look -w prev"))
hl.bind(mainMod .. " + CTRL + RIGHT", hl.dsp.exec_cmd("${PREFIX}-look -w next"))
hl.bind(mainMod .. " + SHIFT + M",    hl.dsp.exec_cmd("${PREFIX}-look --menu"))

-- -----------------------------------------------------------------------------
-- ◆ APPLICATIONS & BROWSERS
-- -----------------------------------------------------------------------------
hl.bind(mainMod .. " + B",        hl.dsp.exec_cmd("${PREFIX}-run start browser"))
hl.bind(mainMod .. " + K",        hl.dsp.exec_cmd("${PREFIX}-run start editor"))
hl.bind("ALT + CTRL + M",         hl.dsp.exec_cmd("${PREFIX}-run start mail"))
hl.bind(mainMod .. " + E",        hl.dsp.exec_cmd("${PREFIX}-run start fileman"))
hl.bind(mainMod .. " + S",        hl.dsp.exec_cmd("${PREFIX}-run -s a catfish"))
hl.bind(mainMod .. " + RETURN",   hl.dsp.exec_cmd("${PREFIX}-run start term"))
hl.bind("ALT + CTRL + RETURN",    hl.dsp.exec_cmd("${PREFIX}-run -s a alacritty"))

-- -----------------------------------------------------------------------------
-- ◆ FOCUS, MOVE & MOUSE BINDINGS
-- -----------------------------------------------------------------------------
hl.bind(mainMod .. " + LEFT",  hl.dsp.focus({ direction = "left" }))
hl.bind(mainMod .. " + RIGHT", hl.dsp.focus({ direction = "right" }))
hl.bind(mainMod .. " + UP",    hl.dsp.focus({ direction = "up" }))
hl.bind(mainMod .. " + DOWN",  hl.dsp.focus({ direction = "down" }))

hl.bind("ALT + CTRL + LEFT",  hl.dsp.window.move({ direction = "left" }))
hl.bind("ALT + CTRL + RIGHT", hl.dsp.window.move({ direction = "right" }))
hl.bind("ALT + CTRL + UP",    hl.dsp.window.move({ direction = "up" }))
hl.bind("ALT + CTRL + DOWN",  hl.dsp.window.move({ direction = "down" }))

-- Mouse Binds
hl.bind(mainMod .. " + mouse:272", hl.dsp.window.drag(),   { mouse = true })
hl.bind(mainMod .. " + mouse:273", hl.dsp.window.resize(), { mouse = true })

-- -----------------------------------------------------------------------------
-- ◆ WORKSPACE MANAGEMENT (Dynamic Loop 1 - 10)
-- -----------------------------------------------------------------------------
for i = 1, 10 do
    local key = i % 10 -- 10 maps to '0'
    hl.bind(mainMod .. " + " .. key,        hl.dsp.focus({ workspace = i }))
    hl.bind("ALT + SHIFT + " .. key,       hl.dsp.window.move({ workspace = i }))
    hl.bind("ALT + CTRL + " .. key,        hl.dsp.window.move({ workspace = i, silent = true }))
    end

    -- Scroll Workspace
    hl.bind(mainMod .. " + mouse_down", hl.dsp.focus({ workspace = "e+1" }), { mouse = true })
    hl.bind(mainMod .. " + mouse_up",   hl.dsp.focus({ workspace = "e-1" }), { mouse = true })

    -- -----------------------------------------------------------------------------
    -- ◆ VOLUME & BRIGHTNESS CONTROLS
    -- -----------------------------------------------------------------------------
    hl.bind("code:122", hl.dsp.exec_cmd("${PREFIX}-ctrl --volume dec"), { locked = true, repeating = true })
    hl.bind("code:123", hl.dsp.exec_cmd("${PREFIX}-ctrl --volume inc"), { locked = true, repeating = true })
    hl.bind("code:121", hl.dsp.exec_cmd("${PREFIX}-ctrl --volume toggle"), { locked = true, repeating = true })
    hl.bind("XF86AudioMicMute", hl.dsp.exec_cmd("${PREFIX}-ctrl --volume mic-toggle"), { locked = true, repeating = true })

    hl.bind("code:232", hl.dsp.exec_cmd("${PREFIX}-ctrl --brightness inc"), { locked = true, repeating = true })
    hl.bind("code:233", hl.dsp.exec_cmd("${PREFIX}-ctrl --brightness dec"), { locked = true, repeating = true })

    -- -----------------------------------------------------------------------------
    -- ◆ SCREENSHOTS & CLIPBOARD
    -- -----------------------------------------------------------------------------
    hl.bind("CTRL + SHIFT + PRINT", hl.dsp.exec_cmd("${PREFIX}-look -s full"))
    hl.bind("SHIFT + PRINT",        hl.dsp.exec_cmd("${PREFIX}-look -s edit"))
    hl.bind("ALT + PRINT",          hl.dsp.exec_cmd("${PREFIX}-look -s area"))

    hl.bind(mainMod .. " + V", hl.dsp.exec_cmd("cliphist list | wofi --dmenu | cliphist decode | wl-copy"))

    -- -----------------------------------------------------------------------------
    -- ◆ SPECIAL WORKSPACE & MEDIA CONTROLS
    -- -----------------------------------------------------------------------------
    hl.bind("ALT + CTRL + S", hl.dsp.workspace.toggle_special("magic"))

    hl.bind("code:172", hl.dsp.exec_cmd("playerctl play-pause"), { locked = true })
    hl.bind("code:171", hl.dsp.exec_cmd("playerctl next"),       { locked = true })
    hl.bind("code:173", hl.dsp.exec_cmd("playerctl previous"),   { locked = true })

    -- -----------------------------------------------------------------------------
    -- ◆ EXTERNAL MODULE REQUIRE (hypremoji)
    -- -----------------------------------------------------------------------------
    local config = os.getenv("XDG_CONFIG_HOME") or (os.getenv("HOME") .. "/.config")

    package.path = package.path .. ";" .. config .. "/?.lua"
    package.path = package.path .. ";" .. config .. "/?/init.lua"

    require("hypremoji.hypremoji")
