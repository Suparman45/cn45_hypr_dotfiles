-- ==========================================================================
-- Window Rules Configuration
-- https://github.com/Suparman45
-- ==========================================================================

-- -----------------------------------------------------------------------------
-- ◆ TAG DEFINITIONS (Categorization)
-- -----------------------------------------------------------------------------
local tags = {
    browser          = { class = "^(firefox|org%.mozilla%.firefox|brave|Brave-browser|chromium|google-chrome|code)$" },
    terminal         = { class = "^(foot|kitty)$" },
    ["terminal-pop"] = { title = "^(Scratchpad|termfloat)$" },
    ["file-manager"] = { class = "^(nautilus|thunar|nemo)$" },
    settings         = { class = "^(pavucontrol|org%.pulseaudio%.pavucontrol|com%.saivert%.pwvucontrol|nmtui|nm-connection-editor|zenity|Zenity|yad|Yad|qt5ct|qt6ct|catfish)$" },
    viewer           = { class = "^(gnome-system-monitor|org%.gnome%.SystemMonitor|io%.missioncenter%.MissionCenter)$" },
    im               = { class = "^(TelegramDesktop|discord|Signal|whatsapp-desktop|vesktop)$" },
    multimedia       = { class = "^(mpv|vlc)$" },
    games            = { class = "^(steam_app_%d+|gamescope)$" },
    gui              = { title = "^(wallpapers|modules|configs)$" },
}

windowrules = {}

-- Automatic tag registration
for tag_name, match_rule in pairs(tags) do
    table.insert(windowrules, { match = match_rule, tag = "+" .. tag_name })
    end

    -- -----------------------------------------------------------------------------
    -- ◆ FLOATING & LAYOUT RULES
    -- -----------------------------------------------------------------------------
    local float_tags = { "settings", "viewer", "gui", "terminal-pop" }
    for _, tag in ipairs(float_tags) do
        table.insert(windowrules, { match = { tag = tag }, float = true })
        end

        -- Dialogs & System Popups (Auto-Float + Center)
        table.insert(windowrules, {
            match = {
                title = "^(Authentication Required|Confirm|Error|Settings|Preferences|About|Properties)$",
                     class = "^(waydroid-helper|CN45 Security)$",
            },
            float  = true,
            center = true,
        })

        -- Force Tiling
        local tile_tags = { "browser", "file-manager", "im" }
        for _, tag in ipairs(tile_tags) do
            table.insert(windowrules, { match = { tag = tag }, tile = true })
            end

            -- -----------------------------------------------------------------------------
            -- ◆ POSITIONING & SIZING RULES
            -- -----------------------------------------------------------------------------
            local size_and_moves = {
                -- Audio Controls
                { match = { class = "^(pavucontrol|org%.pulseaudio%.pavucontrol|com%.saivert%.pwvucontrol)$" }, size = { 400, 360 }, move = { 1500, 65 } },
                -- Network Controls
                { match = { class = "^(nmtui|nm-connection-editor)$" },                                           size = { 420, 380 }, move = { 1400, 65 } },
                -- Yad Dialogs
                { match = { class = "^(yad|Yad)$" },                                                              size = { 400, 300 }, move = { 750, 65 } },
                -- Scratchpad Terminal
                { match = { tag = "terminal-pop" },                                                               size = { 800, 480 }, move = { "30%", "20%" }, pin = true },
                -- Quick Centered Windows
                { match = { tag = "viewer" },                                                                     size = { 960, 600 }, center = true },
                { match = { tag = "gui" },                                                                        size = { 1200, 800 }, center = true },
                { match = { class = "^(Alacritty|catfish)$" },                                                    size = { 800, 900 }, center = true, float = true },
            }

            for _, rule in ipairs(size_and_moves) do
                table.insert(windowrules, rule)
                end

                -- -----------------------------------------------------------------------------
                -- ◆ OPACITY & VISUAL EFFECTS
                -- -----------------------------------------------------------------------------
                local opacities = {
                    { tag = "browser",      opacity = { 0.90, 0.60 } },
                    { tag = "terminal",     opacity = { 0.70, 0.50 } },
                    { tag = "terminal-pop", opacity = { 0.85, 0.65 } },
                    { tag = "file-manager", opacity = { 0.85, 0.75 } },
                    { tag = "settings",     opacity = { 0.80, 0.70 } },
                    { tag = "viewer",       opacity = { 0.82, 0.75 } },
                    { tag = "im",           opacity = { 0.94, 0.86 } },
                    { tag = "gui",          opacity = { 0.60, 0.40 } },
                }

                for _, rule in ipairs(opacities) do
                    table.insert(windowrules, { match = { tag = rule.tag }, opacity = rule.opacity })
                    end

                    -- Custom opacity override for Alacritty & Catfish
                    table.insert(windowrules, {
                        match   = { class = "^(Alacritty|catfish)$" },
                                 opacity = { 0.85, 0.50 },
                    })

                    -- Media (No Blur & Full Opacity)
                    table.insert(windowrules, {
                        match   = { tag = "multimedia" },
                        opacity = { 1.0 },
                        no_blur = true,
                    })

                    -- -----------------------------------------------------------------------------
                    -- ◆ LAYER RULES
                    -- -----------------------------------------------------------------------------
                    layerrules = {
                        {
                            match   = { namespace = "nwg-dock-hyprland" },
                            blur    = true,
                            no_anim = true,
                        },
                        {
                            match = { namespace = "gtk-layer-shell" },
                            blur  = true,
                        },
                    }
