-- ==========================================================================
-- == Animation Configs
-- https://github.com/Suparman45
-- ==========================================================================

hl.config({
    animations = {
        enabled = true,
    },
})

-- -----------------------------------------------------------------------------
-- ◆ CURVES DEFINITIONS
-- -----------------------------------------------------------------------------
hl.curve("default", {
    type = "bezier",
    points = {
        { 0.05, 0.90 },
        { 0.10, 1.00 },
    },
})

-- -----------------------------------------------------------------------------
-- ◆ ANIMATION RULES
-- -----------------------------------------------------------------------------
local animations = {
    { leaf = "windows",          enabled = true, speed = 4,   bezier = "default", style = "slide" },
    { leaf = "windowsIn",        enabled = true, speed = 4,   bezier = "default", style = "popin 85%" },
    { leaf = "windowsOut",       enabled = true, speed = 4,   bezier = "default", style = "slide" },
    { leaf = "windowsMove",      enabled = true, speed = 4,   bezier = "default" },
    { leaf = "border",           enabled = true, speed = 2,   bezier = "default" },
    { leaf = "borderangle",      enabled = true, speed = 100, bezier = "default", style = "loop" },
    { leaf = "fade",             enabled = true, speed = 3,   bezier = "default" },
    { leaf = "layersIn",         enabled = true, speed = 3,   bezier = "default", style = "slide" },
    { leaf = "layersOut",        enabled = true, speed = 3,   bezier = "default", style = "fade" },
    { leaf = "fadeLayersIn",     enabled = true, speed = 3,   bezier = "default" },
    { leaf = "fadeLayersOut",    enabled = true, speed = 3,   bezier = "default" },
    { leaf = "workspaces",       enabled = true, speed = 4,   bezier = "default", style = "slidefade 20%" },
    { leaf = "specialWorkspace", enabled = true, speed = 4,   bezier = "default", style = "slidefade 20%" },
}

-- Automatic animation registration
for _, anim in ipairs(animations) do
    hl.animation(anim)
    end
