-- ==========================================================================
-- == Environment Variables
-- https://github.com/Suparman45
-- ==========================================================================

local dsp = hl.dsp or hl

-- 1. Helper function dengan Opsi Overwrite & Safe Execution
local function set_env(name, value, overwrite)
if not overwrite and os.getenv(name) then
    return
    end

    local val_str = tostring(value)

    if dsp and type(dsp.env) == "function" then
        dsp.env(name, val_str)
        elseif hl and type(hl.exec_cmd) == "function" then
            hl.exec_cmd(string.format("hyprctl keyword env %s,%s", name, val_str))
            end
            end

            -- 2. Modul batch setter untuk performa dan kemudahan pemeliharaan
            local function batch_set_env(env_table)
            for name, val in pairs(env_table) do
                set_env(name, val)
                end
                end

                -----------------------------------------------------
                -- Environment Configurations
                -----------------------------------------------------
                batch_set_env({
                    -- Desktop / Session
                    XDG_CURRENT_DESKTOP                 = "Hyprland",
                    XDG_SESSION_DESKTOP                 = "Hyprland",
                    XDG_SESSION_TYPE                    = "wayland",

                    -- Toolkit Backends
                    GDK_BACKEND                         = "wayland,x11;*",
                    QT_QPA_PLATFORM                     = "wayland;xcb",
                    CLUTTER_BACKEND                     = "wayland",
                    SDL_VIDEODRIVER                     = "wayland,x11",
                    _GLFW_USE_WAYLAND                   = "1",

                    -- Scaling & Decoration
                    GDK_SCALE                           = "1",
                    QT_SCALE_FACTOR                     = "1",
                    QT_AUTO_SCREEN_SCALE_FACTOR         = "1",
                    QT_WAYLAND_DISABLE_WINDOWDECORATION = "1",

                    -- Qt Appearance
                    QT_STYLE_OVERRIDE                   = "kvantum",
                    QT_QPA_PLATFORMTHEME                = "qt6ct",
                    QT_QUICK_CONTROLS_STYLE             = "org.kde.desktop",

                    -- Apps Performance & Wayland Native
                    MOZ_ENABLE_WAYLAND                  = "1",
                    MOZ_WEBRENDER                       = "1",
                    ELECTRON_OZONE_PLATFORM_HINT        = "auto",
                    _JAVA_AWT_WM_NONREPARENTING         = "1",
                    GST_VAAPI_ALL_DRIVERS               = "1",

                    -- Fcitx5 Input Method Modern Standard
                    GTK_IM_MODULE                       = "fcitx",
                    QT_IM_MODULE                        = "fcitx",
                    XMODIFIERS                          = "@im=fcitx",
                    INPUT_METHOD                        = "fcitx",
                    SDL_IM_MODULE                       = "fcitx",
                    GLFW_IM_MODULE                      = "ibus",

                    -- Hyprland & Aquamarine Optimizations
                    HYPRLAND_NO_RT                      = "1",
                    HYPRLAND_LOG_WLR                    = "0",
                    HYPRLAND_DISABLE_SPLASH             = "1",
                    AQ_TRACE                            = "0",
                    AQ_MGPU_NO_EXPLICIT                 = "1",
                    AQ_NO_MODIFIERS                     = "1",
                })
