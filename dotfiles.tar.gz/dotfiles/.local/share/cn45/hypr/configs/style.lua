-- ==========================================================================
-- == Hybrid Style Config (Plasma Dark Gradient Border Style)
-- * https://github.com/Suparman45
-- ==========================================================================

hl.config({

    -- -------------------------------------------------------------------------
    -- ◆ GENERAL SETTINGS
    -- -------------------------------------------------------------------------
    general = {
        -- Layout spacing
        gaps_in = 6,
        gaps_out = 10,
        border_size = 2,

        -- Border colors
        col = {
            active_border = "rgba(33ccffff)",
          inactive_border = "rgba(8a2be2ff)",
        },

        resize_on_border = true,
    },

    -- -------------------------------------------------------------------------
    -- ◆ DECORATION
    -- -------------------------------------------------------------------------
    decoration = {
        rounding = 10,

        -- Window opacity
        active_opacity = 0.70,
        inactive_opacity = 0.50,
        fullscreen_opacity = 1.0,

        -- Dim inactive windows
        dim_inactive = true,
        dim_strength = 0.12,

        -- ---------------------------------------------------------------------
        -- ◆ BLUR SETTINGS
        -- ---------------------------------------------------------------------
        blur = {
            enabled = true,
          size = 6,
          passes = 3,
          new_optimizations = true,
        },

        -- ---------------------------------------------------------------------
        -- ◆ SHADOW SETTINGS
        -- ---------------------------------------------------------------------
        shadow = {
            enabled = true,
          range = 8,
          render_power = 2,
          offset = "3 3",
        },
    },

})
