-- ==========================================================================
-- == Settings Configuration
-- * https://github.com/Suparman45
-- ==========================================================================

hl.config({

  -- -------------------------------------------------------------------------
  -- ◆ GENERAL SETTINGS
  -- -------------------------------------------------------------------------
  general = {
    resize_on_border = true,
    layout = "dwindle", -- "dwindle" or "master"
  },

  -- -------------------------------------------------------------------------
  -- ◆ DWINDLE LAYOUT
  -- -------------------------------------------------------------------------
  dwindle = {
    preserve_split = true,
    -- smart_split = true,
    special_scale_factor = 0.8,
  },

  -- -------------------------------------------------------------------------
  -- ◆ MASTER LAYOUT
  -- -------------------------------------------------------------------------
  master = {
    new_status = "master",
    new_on_top = 1,
    mfact = 0.5,
  },

  -- -------------------------------------------------------------------------
  -- ◆ INPUT CONFIGURATION
  -- -------------------------------------------------------------------------
  input = {
    kb_layout = "us,id",
    kb_variant = "",
    kb_model = "",
    kb_options = "",
    kb_rules = "",

    repeat_rate = 50,
    repeat_delay = 300,

    sensitivity = 1,

    -- accel_profile = "flat",

    numlock_by_default = true,
    left_handed = false,

    follow_mouse = 1,
    mouse_refocus = true,
    float_switch_override_focus = false,

    touchpad = {
      disable_while_typing = true,
      natural_scroll = true,
      clickfinger_behavior = false,
      middle_button_emulation = false,
      tap_to_click = true,
      drag_lock = false,
    },

    -- Touchscreen
    touchdevice = {
      enabled = true,
    },

    -- Tablet
    tablet = {
      transform = 0,
      left_handed = 0,
    },
  },

  -- -------------------------------------------------------------------------
  -- ◆ GESTURES CONFIGURATION
  -- -------------------------------------------------------------------------
  gestures = {
    workspace_swipe_distance = 500,
    workspace_swipe_invert = true,

    workspace_swipe_min_speed_to_force = 30,
    workspace_swipe_cancel_ratio = 0.5,

    workspace_swipe_create_new = true,
    workspace_swipe_forever = true,

    workspace_swipe_use_r = true,
  },

  -- -------------------------------------------------------------------------
  -- ◆ MISC SETTINGS
  -- -------------------------------------------------------------------------
  misc = {
    disable_hyprland_logo = true,
    disable_splash_rendering = true,

    vrr = 2,

    mouse_move_enables_dpms = true,

    enable_swallow = false,
    swallow_regex = "^(kitty)$",

          focus_on_activate = false,

          initial_workspace_tracking = 0,

          middle_click_paste = false,

          -- Application Not Responding
          enable_anr_dialog = true,
          anr_missed_pings = 15,
  },

  -- -------------------------------------------------------------------------
  -- ◆ OPENGL
  -- -------------------------------------------------------------------------
  -- opengl = {
  --     nvidia_anti_flicker = true,
  -- },

  -- -------------------------------------------------------------------------
  -- ◆ KEYBIND BEHAVIOR
  -- -------------------------------------------------------------------------
  binds = {
    workspace_back_and_forth = true,
    allow_workspace_cycles = true,

    pass_mouse_when_bound = false,
  },

  -- -------------------------------------------------------------------------
  -- ◆ XWAYLAND
  -- -------------------------------------------------------------------------
  xwayland = {
    enabled = true,
    force_zero_scaling = true,
  },

  -- -------------------------------------------------------------------------
  -- ◆ RENDER SETTINGS
  -- -------------------------------------------------------------------------
  render = {
    direct_scanout = 0,
  },

  -- -------------------------------------------------------------------------
  -- ◆ CURSOR CONFIGURATION
  -- -------------------------------------------------------------------------
  cursor = {
    sync_gsettings_theme = true,

    -- 1 = disable hardware cursor
    -- 2 = auto
    no_hardware_cursors = 2,

    enable_hyprcursor = true,

    warp_on_change_workspace = 2,

    no_warps = true,
  },

})
