-- ==========================================================================
-- == Hyprland Home
-- https://github.com/Suparman45
-- ==========================================================================

-- ◆ Environment Path Resolution with Safe Fallbacks
local HOME = os.getenv("HOME") or ("/home/" .. (os.getenv("USER") or ""))
local XDG_CONFIG = os.getenv("XDG_CONFIG_HOME") or (HOME .. "/.config")
local CN45_DATA = os.getenv("CN45_DATA_DIR") or (HOME .. "/.local/share/cn45")

-- ◆ Helper: Safe Non-Blocking Module Import
local function safe_require(module_name)
local ok, err = pcall(require, module_name)
if not ok then
    io.stderr:write(string.format("[HyprLoader ERROR] Failed to load module '%s': %s\n", module_name, err))
    end
    return ok
    end

    -- ◆ Dynamic Package Path Injection
    local search_paths = {
        XDG_CONFIG .. "/hypr/?.lua",
        XDG_CONFIG .. "/hypr/?/init.lua",
        CN45_DATA .. "/hypr/?.lua",
        CN45_DATA .. "/hypr/?/init.lua",
    }

    package.path = table.concat(search_paths, ";") .. ";" .. package.path

    -- ◆ Load Required Configuration Modules
    local core_modules = {
        "monitors",   -- Loads from $XDG_CONFIG_HOME/hypr/monitors.lua
        "workspaces", -- Loads from $XDG_CONFIG_HOME/hypr/workspaces.lua
        "loader",     -- Loads from $CN45_DATA_DIR/hypr/loader.lua
    }

    for _, module_name in ipairs(core_modules) do
        safe_require(module_name)
        end
