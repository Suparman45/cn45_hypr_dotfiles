# /* https://github.com/Suparman45 */
# GPU detection
# This script detects available GPUs and applies GPU-specific
# environment variables. User overrides can be placed in scripts
# alphabetically after this one.

cmd_exists() {
  command -v "$1" >/dev/null 2>&1
}

detect_nvidia() {
  if cmd_exists nvidia-smi && nvidia-smi >/dev/null 2>&1; then
    echo 1
  elif lsmod | grep -q 'nvidia'; then
    echo 1
  else
    echo 0
  fi
}

detect_amd() {
  if cmd_exists lspci && lspci -nn | grep -E "(VGA|3D)" | grep -iq "1002"; then
    echo 1
  else
    echo 0
  fi
}

detect_intel() {
  if cmd_exists lspci && lspci -nn | grep -E "(VGA|3D)" | grep -iq "8086"; then
    echo 1
  else
    echo 0
  fi
}

detect_nouveau() {
  if lsmod | grep -q 'nouveau'; then
    echo 1
  else
    echo 0
  fi
}

detect_nvidia_vaapi() {
  if [ -f "/usr/lib/dri/nvidia_drv_video.so" ] || [ -f "/usr/lib64/dri/nvidia_drv_video.so" ]; then
    echo 1
  else
    echo 0
  fi
}

NVIDIA=$(detect_nvidia)
AMD=$(detect_amd)
INTEL=$(detect_intel)
NOUVEAU=$(detect_nouveau)
NVIDIA_VAAPI=$(detect_nvidia_vaapi)

key="${AMD}${INTEL}${NOUVEAU}${NVIDIA}"

# -----------------------------------------
# Universal GPU environment variables
# (applies to all GPUs unless overridden)
# -----------------------------------------
export WLR_RENDERER=gl
export WLR_BACKENDS=drm,libinput
export WLR_NO_HARDWARE_CURSORS=0
export GBM_BACKEND=native

case "$key" in

0101)
  GPU_SETUP="hybrid-intel-nvidia"
  export __GLX_VENDOR_LIBRARY_NAME=nvidia
  export VK_LAYER_NV_optimus=1

  if [ "$NVIDIA_VAAPI" = "1" ]; then
    export NVD_BACKEND=direct
  fi

  # Mesa tuning for Intel
  export MESA_GLTHREAD=true
  export MESA_NO_ERROR=1
  export vblank_mode=0
  ;;

1100)
  GPU_SETUP="hybrid-amd-intel"
  # Mesa tuning (both AMD & Intel benefit)
  export MESA_GLTHREAD=true
  export MESA_NO_ERROR=1
  export vblank_mode=0
  export MESA_SHADER_CACHE_DIR="$XDG_CACHE_DIR/mesa"
  export MESA_GLSL_CACHE_DIR="$XDG_CACHE_DIR/mesa"
  ;;

0110)
  GPU_SETUP="hybrid-intel-nouveau"
  # Mesa tuning for Intel only
  export MESA_GLTHREAD=true
  export MESA_NO_ERROR=1
  export vblank_mode=0
  ;;

0001)
  GPU_SETUP="nvidia-only"

  export LIBVA_DRIVER_NAME=nvidia
  export __GLX_VENDOR_LIBRARY_NAME=nvidia
  export __GL_VRR_ALLOWED=1
  export GBM_BACKEND=nvidia-drm
  export GSK_RENDERER=ngl
  export MOZ_DISABLE_RDD_SANDBOX=1
  export EGL_PLATFORM=wayland

  if [ "$NVIDIA_VAAPI" = "1" ]; then
    export NVD_BACKEND=direct
  fi
  ;;

1000)
  GPU_SETUP="amd-only"
  export MESA_GLTHREAD=true
  export MESA_NO_ERROR=1
  export vblank_mode=0
  export MESA_SHADER_CACHE_DIR="$XDG_CACHE_DIR/mesa"
  export MESA_GLSL_CACHE_DIR="$XDG_CACHE_DIR/mesa"
  ;;

0010)
  GPU_SETUP="nouveau-only"
  # No Mesa optimizations for Nouveau (often unstable)
  ;;

0100)
  GPU_SETUP="intel-only"
  export MESA_GLTHREAD=true
  export MESA_NO_ERROR=1
  export vblank_mode=0
  export MESA_SHADER_CACHE_DIR="$XDG_CACHE_DIR/mesa"
  export MESA_GLSL_CACHE_DIR="$XDG_CACHE_DIR/mesa"
  ;;

*)
  GPU_SETUP="unknown or unsupported GPU combination"
  ;;
esac

export GPU_SETUP
${PREFIX}-log -i "GPU setup detected: $GPU_SETUP"

