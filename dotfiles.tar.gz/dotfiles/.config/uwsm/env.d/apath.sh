#!/usr/bin/env sh
# ======================================
# Path Default
# https://github.com/Suparman45
#=======================================

# -----------------------------
# XDG Base Paths
# -----------------------------
XDG_CONFIG_HOME="$HOME/.config"
XDG_LOCAL_HOME="$HOME/.local"
XDG_CACHE_HOME="$HOME/.cache"

# -----------------------------
# Image Paths
# -----------------------------
WALL_DIR="$HOME/Pictures/wallpapers"
SSHOT_DIR="$HOME/Pictures/Screenshots"
MPV_DIR="$HOME/Videos/mpvpapers"

# -----------------------------
# CN45 Structure
# -----------------------------
PREFIX="cn45"
PATH="$XDG_LOCAL_HOME/bin:$XDG_LOCAL_HOME/share/cn45/lib:$PATH"
CN45_CONFIG_DIR="$XDG_CONFIG_HOME/cn45"
CN45_CACHE_DIR="$XDG_CACHE_HOME/cn45"
CN45_DATA_DIR="$XDG_LOCAL_HOME/share/cn45"
CN45_STATE_DIR="$XDG_LOCAL_HOME/state/cn45"

# Export Path
export XDG_CONFIG_HOME XDG_LOCAL_HOME XDG_CACHE_HOME PREFIX PATH CN45_DATA_DIR CN45_CONFIG_DIR CN45_STATE_DIR CN45_CACHE_DIR WALL_DIR MPV_DIR SSHOT_DIR
