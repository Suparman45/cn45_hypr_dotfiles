-- ==========================================================================
-- Hyprland Home
-- https://github.com/Suparman45
-- ==========================================================================

-- Environment path setup
local HOME = os.getenv("HOME") or ("/home/" .. (os.getenv("USER") or ""))
local CN45_DATA = os.getenv("CN45_DATA_DIR") or (HOME .. "/.local/share/cn45")

-- Register module path and execute safely
package.path = CN45_DATA .. "/hypr/?.lua;" .. package.path
pcall(require, "land")
